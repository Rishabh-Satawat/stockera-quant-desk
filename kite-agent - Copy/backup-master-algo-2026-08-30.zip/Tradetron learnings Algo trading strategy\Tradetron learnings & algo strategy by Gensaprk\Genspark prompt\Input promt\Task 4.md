=========================================================
TASK 4 — RUNTIME VARIABLES, STATE AND THE COUNTER MODEL
Deliverables: 05_RUNTIME_VARS.md · 13_FAILURE_LOG.md (append)
Prerequisite: Tasks 1-3 complete. 12_KEYWORD_LEDGER.md and
28_TT_SCHEMA_SPEC.md exist.
Inherits all evidence-tagging, self-review, hub-write and
closing rules from Task 1.
=========================================================

OBJECTIVE
Tradetron strategies are stateful in ways the builder does
not make visible. This task documents the state model
completely: what is remembered, for how long, keyed to
what, and what happens when stale state meets a fresh
trade. Then it AUDITS the operator's live strategy against
that model.

THE GATE HAS MOVED — READ THIS BEFORE PLANNING
The original gate for this task was "capture-at-trigger-vs
-fill resolved." That is now ANSWERED from official
documentation and you must not spend budget re-deriving it:

  Runtime variables capture AT TRIGGER. "The moment your
  entry fires, the variable is created and the value is
  locked in." Available in Entry, Repairs and Set Exits.
  src: help.tradetron.tech/en/article/runtime-variables-in-
  tradetron-capture-once-use-anywhere-83nahv/
  updated 27/05/2026  [V]

Your job is to take that as the starting point and pursue
its CONSEQUENCES, which are unexamined and expensive. The
new gate is the reset audit in 4.4.

---------------------------------------------------------
4.1 THE TRIGGER-VS-FILL GAP — QUANTIFY IT
---------------------------------------------------------
Capture-at-trigger means any credit-relative threshold is
measured against the price that EXISTED when the condition
fired, not the price actually received.

Establish:
 - Is the captured value the price at condition evaluation,
   at order generation, or at order acknowledgement? The
   documentation says "the moment your entry fires" — that
   phrase is ambiguous between the first two. Determine
   which, or declare it [U] and say what would settle it.
 - Does the gap apply to ALL captured values or only price-
   derived ones? An EMA captured at trigger has no fill
   equivalent; an LTP does. Separate these.
 - Direction of the error: for a SHORT premium entry, is
   the captured credit systematically HIGHER or LOWER than
   the credit received? State it, with the reasoning shown.
 - Magnitude: using the operator's own fill data, estimate
   the per-leg and total gap on a four-leg SENSEX iron fly.
   If no fill data is available, say so and specify exactly
   what data you need.

Then answer the operational question: is a credit-relative
exit built on trigger-captured values ACCEPTABLE, or does
it need a correction factor? If a correction factor, how
would it be expressed inside the condition builder, and is
it sweepable given the Task 1 Q8 finding that only literal
numbers are discoverable?

Do NOT recommend "use fill price instead" without first
establishing whether any keyword exposes fill price at all.
Check Position Detail — documentation describes it as
returning five values for the traded instrument including
PRICE. Determine whether that PRICE is the fill or the
trigger, because if it is the fill, this whole section has
a clean answer and it changes the recommendation.

---------------------------------------------------------
4.2 THE PERSISTENCE MODEL — DOCUMENT IT EXACTLY
---------------------------------------------------------
Confirmed from documentation, to be verified and expanded:
 - Variables are stored AT STRATEGY LEVEL, not per trade.
 - They persist across the cycle and remain active UNTIL A
   UNIVERSAL EXIT, unless reset manually.
 - Manual reset = create the same variable again after exit
   and assign it zero.
 - With multiple sets, variables can be defined and reset
   independently per set.

Resolve, each tagged:
 - Are variables scoped per SET or per STRATEGY? The
   documentation says strategy-level storage but per-set
   definition and reset. Those are in tension. Which wins
   when two sets write the same variable name?
 - What survives a Universal Exit versus a Set Exit?
 - What survives a run-counter change?
 - What survives undeploy/redeploy? (Do not test this —
   the operator has a live deployment and redeploying loses
   open positions. Documentation or MCP only.)
 - Is there any limit on variable count, name length, or
   permitted characters?
 - Can a variable hold a string, an instrument, a strike?
   Init Var documentation says it can set "strikes,
   instruments or any other variable." Confirm the type
   system, and confirm which reader is correct for each
   type — Get Runtime versus Get Runtime Number.

---------------------------------------------------------
4.3 THE COUNTER MODEL — PREREQUISITE, NOT OPTIONAL
---------------------------------------------------------
Almost every state behaviour is keyed to the run counter.
Read help.tradetron.tech/en/article/what-is-a-counter-
1yfhcwe/ and document:
 - what a counter is, what increments it, what does not
 - relationship between counter, deployment, and bot
   assignment
 - how counters interact with Repair Once (which is
   once-per-what, exactly?)

Then the Init Var behaviour, confirmed and to be expanded:
 - Init Vars are written ONCE PER RUN COUNTER, at bot
   assignment, NOT on trade execution and NOT daily.
 - If the strategy stays Active without trading, the
   counter does not change and Init Vars are NOT rewritten
   the next morning.
 - Init Vars may not APPEAR in Runtime Data until a trade
   executes in that counter, even though they were written.
 - Init Vars cannot be used for list-based strategies.
 - They are written at the first condition check per the
   "Start condition check after exchange open" advanced
   setting.
   src: help.tradetron.tech/en/article/initiate-variables-
   feature-1axm72v/ updated 27/02/2026  [V]

State the trap plainly: "variable not visible in Runtime
Data" and "variable never written" are INDISTINGUISHABLE
from the UI. Give the operator a way to tell them apart.

---------------------------------------------------------
4.4 THE RESET AUDIT — THIS IS THE NEW GATE
---------------------------------------------------------
This is the highest-value work in the task.

A strategy that captures entry credit into a runtime
variable and does NOT explicitly reset it after exit will
carry that value into the next trade. The exit condition
then evaluates against a credit from a trade that already
closed. It validates clean, saves clean, reads back clean,
and is wrong. Combined with the Task 1 Q10 finding — a
missing value leaves the containing condition permanently
true or permanently false — this is a live-capital failure
mode with no error message.

Do this:
 1. Using tt_export_strategy or the Task 2 export, list
    EVERY runtime variable the operator's live strategy
    writes, where it is written, and where it is read.
 2. For each, determine whether an explicit reset exists.
 3. For each variable with NO reset, state exactly what
    goes wrong on the second trade of a counter, and
    whether the operator's current exits would fire early,
    late, or never.
 4. Produce the exact reset rows needed, in
    condition-builder form, ready to add.
 5. Check the same for Init Vars: does anything depend on
    an Init Var being refreshed daily? If yes, that is a
    latent bug, because it is refreshed per COUNTER.

Write the findings to 13_FAILURE_LOG.md as dated entries
even if nothing is broken — a clean audit is a result.

---------------------------------------------------------
4.5 BUILDABLE-OR-NOT VERDICT
---------------------------------------------------------
Close with a plain table. For each state-dependent
construct the desk wants, mark BUILDABLE / BUILDABLE WITH
CAVEAT / NOT BUILDABLE, with the reason and the caveat:
 - exit at X% of entry credit
 - exit at fixed rupee profit scaled by multiplier
 - trail a stop from the entry candle's low
 - re-entry limited to N times per counter
 - adjust when a leg's delta breaches a threshold captured
   at entry
 - carry a value across days within one counter
 - carry a value across counters
 - per-leg state in a multi-leg position

Anything marked NOT BUILDABLE needs the escape hatch named:
Python block, external webhook signal, or accept and move
on.

---------------------------------------------------------
STOP AND REPORT
---------------------------------------------------------
a) files written
b) trigger-vs-fill: the precise capture moment, tagged, and
   whether Position Detail PRICE offers a fill-based
   alternative
c) the reset audit — every variable, reset present or
   absent, consequence stated
d) the buildable-or-not table, complete
e) anything contradicting operator material, flagged
f) screenshot checklist for remaining [U] items
g) SELF-REVIEW section

DO NOT modify the live deployment. Read, export, analyse,
recommend. Any fix is proposed for the operator to apply.
