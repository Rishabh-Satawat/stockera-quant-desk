# Tradetron platform knowledge

Source: Rishabh Jain asked all agents to study the Tradetron YouTube channel
(source: target=#channel-fbdaec98:ch_946f012149a777b858fc5db5794f80b4 comet_message_id=3156584 date=2026-08-25 sender=Rishabh Jain/41301041-ba21-4d36-a622-43760e97e3d6)

## Research method / limitation (IMPORTANT — be honest about this)
- Full channel catalogue extracted: **411 videos** (titles + links) → `notes/tradetron-video-catalogue.txt`;
  164 flagged strategy-relevant → `notes/tradetron-video-priority.txt`.
- YouTube transcript/audio extraction is BLOCKED from the sandbox: yt-dlp returns
  HTTP 429 + "Sign in to confirm you're not a bot"; `gsk audio_transcribe` returns
  "Failed to download audio". `gsk summarize_large_document` on a YouTube URL only
  returns title/metadata, NOT the spoken content.
- So: never claim to have "decoded/watched" the videos. The substantive knowledge
  below came from Tradetron's OFFICIAL written docs (help.tradetron.tech,
  qna.tradetron.tech, tradetron.tech/faq), which are quotable and more reliable.

## Strategy section architecture (which keyword works WHERE)
This is the single most important thing — putting a keyword in the wrong section
means it silently never fires.

- **Entry** — entry conditions. `Traded Instrument` IS available here.
- **Repair (Once / Continuous)** — adjustments to an open position. `Traded Instrument`
  IS available here. This is where per-leg SL/target/adjustment logic lives.
  - *Repair Once*: checked once; once satisfied never re-checked **until a set exit
    or universal exit occurs** (that's the reset trigger).
  - *Repair Continuous*: re-evaluated every second → infinite-loop risk unless
    constrained by `Net Quantity` / `LastRepairedPrice`.
- **Set Exit** — exits one set. Use `PNL Underlying` here.
- **Universal Exit** — exits the WHOLE strategy. `PNL` keyword is to be used
  **only in Universal Exit**.

### Verbatim rules worth remembering
- "Traded instrument keyword ... outputs price, Quantity, value of Traded instruments
  in **ENTRY and REPAIRs**." → NOT documented for Universal Exit.
- "The 'PNL Underlying' is to be used in set exit, whereas **PNL keyword is to be
  used only in Universal Exit**."
- "PNL Keyword calculates PNL of the **Entire** Strategy" — even if placed in a Set,
  it still computes whole-strategy PNL. So per-set risk control via `PNL` is impossible;
  use `Traded Instrument (PNL)` for a specific leg.

## Percentage SL / Target (answers Rishabh's direct question)
- **`Leg Exit` keyword** is the purpose-built tool. Parameters: Instrument Name,
  Set no., Condition no., Leg no., then choose **target or stoploss** in
  **percentage or points** + value.
  - "The condition builder will automatically fetch if the position is a long or short
    and based on the same trigger your target or stoploss as needed." → handles the
    short-leg sign inversion for you (big deal for short straddles).
  - Multiple Leg Exits can coexist; "your leg will exit once whichever condition is
    true first."
  - **Limitation (verbatim): "Leg TSL and Leg Exit to be used only if the entry legs
    will trade once, it will not work for reentries."**
- **`Leg TSL`** = per-leg trailing SL. Limitation: usable **once per run counter**;
  only resets after a Universal Exit; re-use needs multiple sets or UE + min 2-minute
  re-entry wait.
- Manual/DIY alternative (the older video approach, still valid):
  `LTP(Traded Instrument Name(set,cond,leg)) >= 1.5 * Traded Instrument(set,cond,leg,'PRICE')`
  = 50% SL on a short leg. Uses `Traded Instrument Name` to fetch the instrument and
  `Traded Instrument ... PRICE` for the entry price. Because it relies on
  `Traded Instrument`, it belongs in **Repair**, not Universal Exit.

### ANSWER to "repair only, or universal exit also?"
Percentage SL/target on a **specific leg** → Repair (or the dedicated `Leg Exit`
keyword). NOT Universal Exit, because it needs `Traded Instrument`, which is
documented for Entry/Repair only.
Percentage-of-credit on the **whole strategy** → Universal Exit is the right place,
but `PNL` returns rupees, so build the % by expressing it against a stored entry
credit (Set Runtime Variable) rather than assuming a % option exists.

## Strategy-level Trailing Stop Loss (Advanced Settings) — I HAD THIS WRONG
Three fields: `Activate at`, `When profit increased by`, `Increase TSL by`.
Verbatim mechanics: "activate the TSL at 3000 profit and then choose to increase it
by 1000 with every 1000 increase in profit. So when the profit touches 4000, the TSL
will be at 1000 and at 5000 profit it will be at 2000; now if the profit drops to
2000, the strategy will exit."

**Key correction: on activation the TSL sits at 0 (break-even), NOT at the activation
value.** So "Activate at 1500" does NOT lock in 1500 — it locks in ZERO, and you only
start banking profit after further gains. My earlier IF-B advice to Rishabh
("once you're +1500 a floor is set") was wrong and was corrected in-thread.

## Other platform facts
- SENSEX: strike interval 100, lot size 20, BFO exchange, weekly expiry **Thursday**
  (NIFTY moved to Tuesday). Product NRML.
- `tt_ATM('SENSEX', n)` → n is in STRIKES, not points. n=12 ⇒ 1200 pts on SENSEX.
- Backtest engine does not reliably serve historical IV / per-strike delta for 0DTE
  BFO options → a Greeks-based entry filter can silently pass every candle.
  `Find Strike (... 'DELTA' ...)` exists for live strike selection but is unreliable
  in backtest for 0DTE.
- Advanced Settings levers: Price execution 1 (Initiation price / Revision attempts /
  Increase by), Price execution 2 (Timeout / Final action / Exit at Market),
  Tranching (Tranch size / One tranch every / Exit Shorts first), Trailing SL,
  Reactivate on exit after, Check conditions every, Capital Required, Take trades
  window, Rollover on expiry, Python code.
- "Capital Required" is a DISPLAY/deploy field — it does not cap margin. Blocked
  margin can far exceed it, which is what inflated Rishabh's ROI/CAGR ~6-7x.
- CAS (Closing Auction Session) on BSE expiry: documented extreme premium spikes;
  being flat before it matters. Tradetron has a dedicated video on this.
- Limit-order bidding / "Immediate Fill" order execution exists specifically to reduce
  slippage in spikes and freak trades — relevant to 0DTE Sensex/Bankex.
- Portfolio-level SL/target exists separately from strategy-level.
- New "Advanced Wizard" (5-part series) covers Entry Settings, Positions, Strike
  Selection, Wait & Trade + Re-entry, Strategy-level SL & TSL, Order Execution &
  Limit Order Bidding, Monetize/Publish.
- Import/Export feature = version control / strategy cloning.

## Useful doc URLs
- help.tradetron.tech/en/category/create-strategy-1lq2eo1/
- help.tradetron.tech/en/category/keywordsstrategy-logics-1miek11/
- help.tradetron.tech/en/article/how-to-use-leg-exit-keyword-on-tradetron-1rnyke4/
- help.tradetron.tech/en/article/difference-between-repair-once-and-repair-continuous-59vglh/
- qna.tradetron.tech/t/pnl-target-stoploss-related-keywords-different-examples-of-its-uses/911
- qna.tradetron.tech/t/how-to-use-traded-instrument-keyword/652
- qna.tradetron.tech/t/how-does-tsl-trailing-stop-loss-works/33
- qna.tradetron.tech/t/where-all-can-we-use-leg-tsl/2467
- tradetron.tech/blog/keywords-in-tradetron
