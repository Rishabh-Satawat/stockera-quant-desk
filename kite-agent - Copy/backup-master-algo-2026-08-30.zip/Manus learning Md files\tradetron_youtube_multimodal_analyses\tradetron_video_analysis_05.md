Starting video analysis...
Submitting video analysis task...
Task submitted (ID: video-analysis-c8ab0427-61dd-4b80-a347-f78c51415277)
[9s] Status: Analyzing video content with AI...
[33s] Still processing, please wait...
[35s] Status: Analysis completed
[35s] Analysis completed!
Full analysis result saved to: /home/ubuntu/video_PN2gpcGHZGw_analysis_20260829_095037.md
Note: This tool performs AI-based visual and audio analysis, not verbatim transcription. For detailed speech transcription, use `manus-speech-to-text` instead.
Analysis result:

This exhaustive analysis of the Tradetron Advanced Wizard video details the user interface, logic, and implementation rules for building automated trading strategies.

### **Chronological UI Walkthrough & Visible Elements**

#### **1. Leg Definition (The Strip)**
*   **Segment/Options:** Default is set to Options.
*   **Action:** Buy/Sell toggle (L1, L2, etc.).
*   **Product:** MIS (Intraday) or NRML (Positional).
*   **Strike Logic:** Dropdown including Specific Strike, ATM, OTM/ITM ladder, Premium-based, and Straddle-based logics.
*   **Specific Strike Field:** Manual entry box (e.g., `25100`).
*   **Round Off:** Checkbox and value field (e.g., `100`).

#### **2. Protection (Target & Stop-Loss)**
*   **TGT (Target):** Dropdown options: `None`, `%`, `pts`, `UL %` (Underlying Percentage), `UL pts` (Underlying Points).
*   **SL (Stop-Loss):** Dropdown options identical to Target.
*   **TSL (Trailing Stop-Loss):** Dropdown options: `None`, `%`, `pts`.
*   **The Four-Box Trail (TSL Parameters):**
    *   **Trigger:** The point at which trailing begins.
    *   **Step:** The amount the stop-loss moves initially (Lock Profit).
    *   **TSL Trigger:** The incremental move in the instrument price.
    *   **TSL Step:** The incremental move of the stop-loss.

#### **3. Re-Entry / Re-Execute Settings**
*   **Checkbox:** Activates the re-entry logic.
*   **RE ENTRY (Max Count):** Dropdown to select how many times a leg can re-enter (up to `20`).
*   **RE-ENTRY TGT/SL:** Secondary target and stop-loss fields specifically for re-entered positions.
*   **Timing Windows:**
    *   `Re-entry / Re-execute only after (time)`: e.g., `09:30`.
    *   `Re-entry / Re-execute only before (time)`: e.g., `14:00`.

#### **4. Wait and Trade Settings**
*   **Checkbox:** Activates momentum-based entry.
*   **Movement Type:** Dropdown including `pts ↑`, `pts ↓`, `% ↑`, `% ↓`, `UL pts ↑`, `UL pts ↓`, and `Immediate`.
*   **Value Field:** The magnitude of movement required (e.g., `10`).
*   **Start/End Time:** Defines the window to capture the reference price (e.g., `09:40`).

#### **5. Move SL to Cost (MSTC)**
*   **Checkbox:** Appears only when multiple legs are added.
*   **MSTC Toggle:** A checkbox added to each individual leg strip once the global setting is enabled.

---

### **Extracted Quotes & Examples**

*   **Core Philosophy:** "More power than the Option Wizard. Far less work than the Advanced Strategy Builder."
*   **UI Efficiency:** "Every control that defines the leg lives on one strip."
*   **TSL Logic Example:** "Assume instrument entered at 100. Trigger is 10 points, Lock is 5 points. At 110, TSL is activated, booking 5 points profit (SL at 105). With a 1:1 ratio, if price goes to 111, SL moves to 106."
*   **Wait and Trade Example:** "At 9:40, the price is 200. We set a 10-point 'pts ↑' requirement. The trade only fires when the price hits 210."
*   **Re-Entry Philosophy:** "Take the trade again... up to 20 re-entries per leg."

---

### **Prerequisites, Warnings & Edge Cases**

*   **Move SL to Cost Prerequisite:** "Move SL to Cost will have to have the same underlying instrument." If Leg 1 is Nifty 50 and Leg 2 is Bank Nifty, MSTC will not function across them.
*   **TSL Confusion Warning:** "This is the field people misread most—don't confuse it with the strategy TSL in the Exit card." The Wizard uses leg-level TSL.
*   **Re-Entry Timing:** Re-entry can be restricted by time to avoid volatile periods like market close or expiry spikes.
*   **Wait and Trade Reference:** The reference price is captured at the "Start Time" defined in the strategy header.

---

### **Re-Entry vs. Ordinary Entry**

| Feature | Ordinary Entry | Re-Entry |
| :--- | :--- | :--- |
| **Trigger** | Strategy conditions or Wait and Trade momentum. | Triggered automatically after a leg exits on Target or Stop-Loss. |
| **Logic** | Initial entry based on strike selection. | Can use the same strike or re-evaluate (e.g., finding a new strike at a specific premium). |
| **Frequency** | Once per strategy cycle. | Up to 20 times per leg. |
| **Timing** | Defined by Start Time. | Defined by specific Re-entry time windows. |

---

### **Safe AI-Agent Construction Rules**

1.  **Leg Linearity:** Always define a leg in a single line: `Direction + Product + Strike + Size + When to Enter + When to Exit`.
2.  **Protection Hierarchy:** Prioritize leg-level Target/SL/TSL before strategy-level exits for granular control.
3.  **Momentum Validation:** Use 'Wait and Trade' to prevent entry during sideways markets; ensure a 'Start Time' is set to capture a valid reference price.
4.  **Recurrence Logic:** Enable 'Re-entry' for scalping strategies, but always set a 'Max Count' to prevent runaway losses.
5.  **Cross-Leg Safety:** When using 'Move SL to Cost', verify that all involved legs share the same `Underlying` (e.g., all NIFTY 50).
6.  **Time Gating:** Always define 'Before Time' for re-entries to ensure positions are not opened too close to market close.
