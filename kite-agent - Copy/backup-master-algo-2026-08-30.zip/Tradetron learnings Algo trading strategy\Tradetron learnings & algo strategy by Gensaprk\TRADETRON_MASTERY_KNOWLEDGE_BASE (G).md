# TRADETRON MASTERY — Knowledge Base & V5 Strategy Spec
Compiled 2026-08-25 from: official @Tradetron channel transcripts (18 videos decoded directly),
Tradetron help centre (help.tradetron.tech), QnA forum (qna.tradetron.tech), and the Hub decode log
(tradetron_videos_learned.csv — 122 videos; Tradetron_Video_Learnings.xlsx — 30 decoded; 411 catalogued).

## 1. Architecture (5 blocks — scope is everything)
A strategy = **Sets**. Each Set = Entry condition -> Positions -> Set Exit, plus **Repair Once** /
**Repair Continuous** blocks, and ONE strategy-wide **Universal Exit**.
- Universal Exit = whole strategy, exits everything, increments run counter. `PNL` lives here ONLY.
- Set Exit = that set's legs only. `PNL Underlying` lives here.
- Repair Once = fires one time (per-leg SL, hedge add). Reset trigger = Set/Universal exit.
- Repair Continuous = re-fires while true (rolling adjustments). Guard with Net Quantity / runtime flags or it loops forever.
- One Repair block PER LEG you want to manage independently.
- `Position Detail` (Value/Quantity/Count) is the guard that stops a 2nd repair after the 1st reduced qty.

## 2. Keyword scope table (memorise)
| Keyword | Scope | Allowed section | Returns |
|---|---|---|---|
| PNL | whole strategy, counter | Universal Exit only | rupees |
| PNL Underlying | per underlying | Set Exit | rupees |
| Traded Instrument | one leg (Set,Cond,Leg) | Entry / Repair | PRICE, QUANTITY, STRIKE, PNL, TIME |
| Max Profit / Max Loss | strategy, counter | Universal Exit | peak P&L |
| Leg Exit | one leg | Repair Once / Set Exit | target/SL points or % |
| Leg TSL | one leg | Repair Once / Set Exit | trailing points or % |
| Position Detail | strategy-wide | any | Value/Quantity/Count |
| Open positions | per instrument | any | BOOLEAN 1/0 |
| Net Delta / Delta Neutral | underlying | any / Qty FX | delta x qty / hedge qty |
| Find Strike | — | Strike FX | strike by LTP/premium/Delta |
| Get Strike | — | Strike FX | nearest strike |
| OHLC Sum | 2 instruments | any | combined premium |
| Multiplier | deployment | anywhere | scale SL/TP/qty |
| Get Runtime | — | anywhere | stored variable (case+space sensitive) |

## 3. Percentage SL/TP — the correct patterns
- Leg-level % SL: `Traded Instrument(...,PRICE)` x factor vs LTP. Short 50% SL => entry x **1.5**; 30% target => x **0.7**. (Ul7q6Rn6ZqM)
- Purpose-built: **Leg Exit** keyword (auto-detects long/short — use positive integers only).
- Leg TSL: 4 params (Activate at / Lock profit / Increase profit by / Increase TSL by). **Activate At must exceed Lock Profit.**
- GOTCHA: Leg Exit/TSL work ONLY if the leg trades once. Mutually exclusive with re-entry.
- Strategy-level trailing: `Max Profit` in Universal Exit — GROUP with AND: (Max Profit >= A) AND (PNL <= Max Profit - B). Separate OR blocks exit at the threshold instantly. (K0h2-TlUtDs)
- Built-in Advanced TSL activates at **zero** profit (not at the activation value).
- Scale with deployment: wrap rupee values in `Multiplier`.

## 4. Backtest engine truth (why fantasy results happen)
Engine does NOT recognise: India VIX, OI keywords (incl. PCR / Max OI), Bid/Ask, Sec, VWAP/VWMA.
Engine does NOT model: execution settings (limit bidding, revisions, timeouts), tranching, SLM, rollovers, MIS/NRML/CNC.
=> Slippage is structurally absent. Exec/VIX/OI improvements must be validated in **paper trading, never backtest**.
- Capital Required is **display-only** — it never caps margin.
- Settings: candle frequency < strategy timeframe; Trade Price = **Open** (indicator rules) / **Close** (LTP rules);
  Type Intraday requires a Universal Exit; Expiry = None for multi-expiry strategies. (ubTaun1XPsk)
- Lot-size change fix: backtest at LCM qty across the change, split P&L per era, divide. SENSEX 10->20 => LCM 20,
  run 2x and divide by 2 for the lot-10 era. (kqYmgmFNL-0)

## 5. Execution mastery
- Immediate Fill (new): option < Rs50 -> +-Rs20 offset; >= Rs50 -> +-35% of LTP. Replaces market orders. (NKit0r4aNs0)
- Limit bidding: initiation LTP, 3-5 revision attempts, +2 ticks, 10s timeout, final = **Execute at Market** (never Ignore on multi-leg). (TmmpC4dumbw, SPJ1_DVErM8)
- Tranching: split big orders (25% x 4 / 1s). **Exit Shorts First = Yes** lowers margin spikes. (YZNnxeUUfyo, GAdr3_ozbRk)
- **Exit at Market Price** = entries/repairs stay limit, exits go market. (-J8JwTlPpGs)
- CAS: exchange close auto-shifted to 15:40; limit-only in CAS; SLL/SLM cancelled after 15:15; be flat before it. (_qIUxpYVPAA)
- On Error settings: error execution -> wait 1 min -> auto Universal Exit. (nDHPLpW5oXU)
- Paper fills at LTP; live fills at best bid/ask — expect a real slippage gap. (z4h45W-BoKk)

## 6. Debug
Condition Builder syntax -> Deployed page -> **Notification log**: continuous logs = Position Builder error;
empty log = debug procedure (fire a trade manually). quantity FX must be 'quantity' not 'value'; F&O needs >= 1 lot. (mjcPRdU6hws)

## 7. Other platform facts
- SENSEX: BFO, strike step 100, lot 20, weekly expiry Thursday, tick 0.05. ATM('SENSEX',n) n = STRIKES not points.
- Initialize Variables: written once per run counter; not for list strategies; case-sensitive; pause+exit to re-init. (fIPKNy1b89I)
- Weekday keyword (1=Mon...); Change % gap filter (fractional 0.01 vs whole 1 gotcha); Days Difference for 0DTE; Position Detail guards.
- Find Strike by premium value = regime-adaptive wings (OB7hCVI6-x4); delta strike unreliable in backtest for 0DTE.
- Indicators: 5/15-min candles match charts; hourly starts 9:15; boundaries shift indicator values (9OdLID8yhX8).
- Stats: Statistics tab (daily chart, capital, PNL, DD, std dev, Sharpe, monthly), Counters, Download data -> trade Excel. (zT1d3SkOQ6k)
- Pricing: Free 10 strats/1 deploy/paper; Starter $15; Retail $50 5 deploys + ~10 backtests/mo; Retail+ $100 12; Creator $300 25. (p3d304cgcZM)

## 8. V5 Strategy spec (SENSEX 0DTE Iron Fly — Tradetron-native)
See companion workbook SENSEX_0DTE_Strategy_V5_Tradetron_Mastery.xlsx, sheet 3_V5_Strategy_Spec.
Headline changes: premium-targeted wings, %-of-credit stops via runtime credit_total, Max-Profit AND-grouped trail,
Leg Exit blow-up stops, 09:45-10:15 entry + 0.6% gap filter, LTP-limit execution 3-5 revisions + tranching,
Exit Shorts First + Exit at Market, 14:45 flat before CAS, On Error auto-exit, Capital 1.5L display / ~4L live,
backtest: 1-min Close Intraday Net-of-costs + LCM lot-proofing, judged on expectancy/PF/DD-duration/21d-Sharpe/weekday.

## 9. Coverage honesty
411 videos catalogued. 18 transcribed directly in-session (listed in xlsx sheet 5). Hub decode log covers 122
(tradetron_videos_learned.csv, read in full) + 30 detailed (Tradetron_Video_Learnings.xlsx). Remainder of the
411 are largely prior-seasons variations (older keyword tutorials, webinars, marketplace showcases) whose core
mechanics are already captured. Gaps: novdiL-G7XM transcript was opaque (summary only); several old 2020-21
autocaption-only clips are unreliable and were not quoted verbatim.
