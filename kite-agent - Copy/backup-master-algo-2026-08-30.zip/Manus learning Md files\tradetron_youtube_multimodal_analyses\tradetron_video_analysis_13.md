Starting video analysis...
Submitting video analysis task...
Task submitted (ID: video-analysis-f93c1f4e-8f10-4b17-a0ac-716342d9c5be)
[8s] Status: Analyzing video content with AI...
[33s] Status: Analysis completed
[33s] Analysis completed!
Full analysis result saved to: /home/ubuntu/video_G9BmdjqIu-8_analysis_20260829_095557.md
Note: This tool performs AI-based visual and audio analysis, not verbatim transcription. For detailed speech transcription, use `manus-speech-to-text` instead.
Analysis result:

This analysis provides an exhaustive breakdown of the Tradetron strategy-build video based on the popular "920 Bank Nifty Strategy" by Ghanshyam Tech.

### **Chronological Visual Walkthrough**

*   **00:00 - 00:50: Introduction & Source.** The presenter introduces the strategy, citing a video by Pushkar Raj Thakur featuring Ghanshyam Tech. He notes that some "discretionary elements" are replaced with specific assumptions for automation.
*   **00:50 - 02:05: Core Entry Logic.** 
    *   **Condition 1: Gap.** Checks for a gap up or gap down in Bank Nifty spot charts.
    *   **Condition 2: 9:20 Range.** Marks the high and low of the first 5-minute candle (ending at 9:20 AM).
    *   **Trigger:** Long if the 9:20 high is broken; Short if the 9:20 low is broken.
*   **02:05 - 03:58: Exit & Stoploss Logic.**
    *   **Target:** 200–250 points in Bank Nifty spot.
    *   **Dynamic Stoploss:** Based on the 9:20 candle size. If >150 points, SL is 100 points. If <150 points, SL is 70 points.
    *   **Trailing/Technical Exit:** If a candle of the opposite color forms and price moves 50 points against the position from that candle's high/low.
*   **03:58 - 04:08: Strategy Metadata.** View of the Tradetron "Edit Strategy" page. Name: "Ghanshyam Tech 920 Option buy".
*   **04:08 - 05:52: Set 1 Entry (Long).** Construction of the condition builder:
    *   Checks if `Close(-1, Day)` > `Open(0, Day) + 100` (Gap down assumption).
    *   Checks if `LTP` > `ORB High (9:15 to 9:19)`.
    *   Time and Position Detail checks.
*   **05:52 - 06:22: Set 1 Position Builder.** Selecting Nifty Bank Call (CE), Current Week, 1 Lot. Strike: `Round(LTP - 100)` to get 100 points ITM.
*   **06:22 - 06:40: Runtime Variables.** Creating `ep_long` to capture the Bank Nifty spot price at entry.
*   **06:40 - 08:27: Set 1 Exit.** Building the 200-point target, dynamic SL (using `Absolute` math for candle size), and the "opposite color + 50 point" logic.
*   **08:27 - 09:10: Set 2 Entry & Position (Short).** Mirroring Set 1 for Put (PE). Strike: `Round(LTP + 100)`. Runtime variable: `ep_short`.
*   **09:10 - 10:00: Set 2 Exit.** Mirroring Set 1 exit logic for the short side.
*   **10:00 - 10:09: Universal Exit.** Set to `Time > 1515` (3:15 PM) for intraday square-off.
*   **10:09 - 10:49: Advanced Settings.** Configuration for reactivation, check frequency, and capital.
*   **10:49 - 11:10: Conclusion.** Final summary and call to action.

---

### **Extracted Strategy Details**

#### **Instrument & Strike Selection**
*   **Underlying:** Nifty Bank (Bank Nifty) Spot.
*   **Instrument:** NFO | Call/Put | Nifty Bank.
*   **Strike Price:** 100 points In-The-Money (ITM). 
    *   *Formula (Long):* `Round(LTP(Bank Nifty Spot), 100) - 100`.
    *   *Formula (Short):* `Round(LTP(Bank Nifty Spot), 100) + 100`.
*   **Expiry:** Current Week.
*   **Quantity:** 1 Lot (Lot size 25 at time of video).

#### **Entry Conditions**
*   **Prerequisite:** Gap of at least 100 points (Presenter's assumption).
*   **Timeframe:** 5-minute candle (09:15 to 09:20).
*   **Long Entry:** `LTP > ORB(High, 09:15, 09:19)` AND `Time >= 920`.
*   **Short Entry:** `LTP < ORB(Low, 09:15, 09:19)` AND `Time >= 920`.
*   **Limit:** `Position Detail (Entry, All, All, Quantity) == 0` (One trade per day).

#### **Exit & Risk Controls**
*   **Target:** `LTP > ep_long + 200` (or `LTP < ep_short - 200`).
*   **Dynamic Stoploss:**
    *   Calculated via `Absolute(ORB_High - ORB_Low)`.
    *   If Size > 150: SL = 100 points from entry.
    *   If Size <= 150: SL = 70 points from entry.
*   **Technical Exit (Long):** `Close(0) < Open(0)` (Red candle) AND `LTP < High(0) - 50`.
*   **Universal Exit:** 15:15 (3:15 PM).

#### **Advanced Settings**
*   **Reactivate on exit after:** 6 hours.
*   **Check conditions every:** Continuously.
*   **Take trades:** 1 second after exchange open.
*   **Capital Required:** 50,000 (includes buffer).

---

### **Key Quotes & Terms**
*   **"Discretionary elements":** Refers to manual trading nuances that the presenter converted into fixed rules (like the 100-point gap).
*   **"ORB Keyword":** "Whenever you use this ORB keyword, you make sure that you select the minute before the minute that you are considering."
*   **"ep_long/ep_short":** Runtime variables used to store the entry price of the *spot* index, not the option.
*   **"Opposite color candle":** A key manual rule from Ghanshyam Tech used to exit early if momentum shifts.

---

### **Warnings & Common Mistakes**
*   **ORB Timing:** A common mistake is setting the ORB end time to 9:20. The video explicitly warns to use **9:19** to capture the 9:15–9:20 candle correctly.
*   **Spot vs. Option Price:** The strategy logic (Target/SL) is based on the **Bank Nifty Spot Index**, not the option premium. This requires using Runtime Variables to track the spot price at the moment the option trade is triggered.
*   **Daily Limit:** Without the `Position Detail` check, the strategy might re-enter multiple times on the same day if the price oscillates around the ORB levels.

---

### **UI Buttons Interacted With**
*   `Condition Builder` (to set logic).
*   `Position Builder` (to define the trade).
*   `Runtime Variable` (to store entry spot price).
*   `Math Operation` -> `Absolute` (for candle size calculation).
*   `Advanced Settings` (for automation parameters).
*   `Update` / `Deploy`.

---

### **AI-Agent Rules for Recreation**

1.  **Variable Initialization:** Create two runtime variables: `ep_long` and `ep_short`. Initialize them to `0` upon exit to prevent logic bleed.
2.  **Candle Definition:** Define the 9:20 candle using the `ORB` function with start time `09:15` and end time `09:19`.
3.  **Gap Logic:** Implement a gap check comparing `Close(-1, Day)` and `Open(0, Day)`. Use a threshold of `100` points.
4.  **Entry Trigger:** Execute only if `Time >= 920` and the current `LTP` of the spot index breaks the `ORB` high (for CE) or low (for PE).
5.  **Strike Math:** Use the `Round` function on the spot `LTP` to the nearest 100, then subtract/add 100 to select an ITM strike.
6.  **Dynamic SL Logic:** Use a nested `OR` condition in the Exit block. Use `Math Operation (Absolute)` to subtract `ORB Low` from `ORB High`. If the result is `> 150`, set SL to `100`; otherwise, set it to `70`.
7.  **Momentum Exit:** Add a condition checking if the current candle is the opposite color of the trade direction AND price has moved `50` points against the position from the current candle's extreme.
8.  **Automation Reset:** Set `Reactivate on exit after` to `6 hours` to ensure the strategy is ready for the next market open.
