# 🧠 BRAIN 2 — Algo Hub Persistent Memory
**Owner:** Rishabh Jain (Algo Trading / Strategy Hub)
**Built:** 2026-08-26
**Source conversations:** Hub sessions + 22 GT-style agent responses + 18 full Tradetron video transcript decodes + 122-row Hub decode log
**Status:** LIVE — read first before answering any /Tradetron /Sensex /Iron-Fly /0DTE /Zerodha question.

---

## A. SESSION INDEX (chronological)

| # | Date | Topic | Outputs |
|---|---|---|---|
| 1 | 2026-08-08 | Sensex Iron Fly V1 logic refinement + SEBI compliance draft | `Tradetron Bear Put Spread logic review request` (archived) |
| 2 | 2026-08-25 | Deep diagnostic of "SENSEX 0DTE Iron Fly" — bugs, rules, walks | `SENSEX_0DTE_Master_Strategy_V4.xlsx` |
| 3 | 2026-08-25 | Tradetron channel mastery — 411 videos + 122 decodes + V5 build | `SENSEX_0DTE_Strategy_V5_Tradetron_Mastery.xlsx`, `TRADETRON_MASTERY_KNOWLEDGE_BASE.md` |
| 4 | 2026-08-26 | **This decode** — BankNifty SUPERTREND crossover entry (5-leg) | `brain2.md` (this file) |

---

## B. PLATFORM CHEAT-SHEET (Tradetron-native)

A strategy = Sets. Each Set = Entry → Positions → Set Exit + Repair Once / Repair Continuous (per leg) + ONE Universal Exit for whole strategy.

**Scope (most-quoted bug source):**
- `PNL` → Universal Exit ONLY.
- `PNL Underlying` → Set Exit.
- `Traded Instrument` → Entry / Repair only; returns PRICE, QTY, STRIKE, PNL, TIME.
- `Max Profit / Max Loss` → Universal Exit; trail must be AND-grouped else exits at threshold instantly.
- `Leg Exit / Leg TSL` → Repair Once / Set Exit; POSITIVE INTEGERS ONLY; auto-detects long vs short; works ONLY if leg trades once (no re-entry).
- `Position Detail` → Value/Qty/Count; multiply threshold by `Multiplier`.
- `Open positions` → BOOLEAN 1/0 (NOT quantity).
- `Net Quantity / Traded Instrument` together → gate repairs + opposite-set exits.
- `OHLC Sum` → combined premium of 2-instrument straddle.
- `Multiplier` → scales SL/TP/qty with deployment level.
- `Get Runtime` → stored variable (case+space sensitive).
- `Initialize Variables` → ONCE per run counter; not for list strategies; pause+exit to re-init.

**Universal Exit language (verbatim and date-stamped):**
- `Time >= Number (time exit)` — minute-of-trading-day.
- `Days Difference = 0` — 0DTE gate.
- `PNL / Multiplier ≤` — %-of-credit scaled.

**Find Strike (verbatim):**
- Args = `Underlying, Select Expiry(offset), Field (ltp|premium|strike|delta…), Number, CE/PE/PUT/CALL, greater/lesser/any`.
- `lesser` = pick LOWER strike than current; `greater` = HIGHER.
- Use as Formula Builder operand inside Strike Fx.

**Position offset (the user got bitten trying to figure this out):**
- `Position(CLOSE(...), -1)` = previous completed candle's close.
- `Position(CLOSE(...), -2)` = two candles back.
- `Position(0)` is INVALID — common mistake from Hub decode.

**Backtest engine truth:**
- Ignores India VIX, all OI, Bid/Ask, VWAP, Sec, VWMA.
- Ignores execution settings (limit bidding, revisions, timeouts), tranching, SLM, rollovers, MIS vs NRML.
- Slippage structurally absent.
- Capital Required is DISPLAY only.
- Candle frequency MUST be < strategy timeframe.
- Trade Price = Open (indicator rules) / Close (LTP rules).
- Intraday requires a Universal Exit.
- Lot-size change fix: run at LCM qty, divide P&L per era. SENSEX 10→20 = LCM 20 → 2x divide-by-2.

**Setting copy:**
- Initiation = LTP / Immediate Fill.
- Revisions 3-5, +2 ticks (regime up to 100-1000 ticks for 0DTE spikes), 10s timeout, Final = **Execute at Market (NEVER Ignore)**.
- Tranching 25%×4, Exit Shorts First = Yes, Exit at Market Price = Yes, Continuous checks, On Error auto-exit.
- CAS: be flat by 14:45 on Thursday expiry (BSE auto-shifts close to 15:40).

---

## C. SENSEX IRON FLY — REGIME ARCHIVE

Contract facts (live-verified):
- Exchange BFO, weekly expiry Thursday (since 2025-09-04), lot 20 (since 2024-11-20), strike step 100.
- Strike 84→77k over 2026 set (live Sensibull 24-Aug-2026 ATM ~77,300).
- Original build: ATM('SENSEX',12') ⇒ ±1200 pts wings ⇒ cost only ₹8 vs ₹294 credit ⇒ decorative hedge.

Backtest scores (Feb–Aug 2026):
- Win 49%, PF 1.48, Sharpe 3.05, Sortino 6.22, Calmar 15.37, Max DD –7.85%, Monte-Carlo 98.9%.
- Capital Required 60k vs Peak Margin 4.02L ⇒ ROI/CAGR/Calmar **all inflated**.
- Thursday-only t-stat 2.3 ⇒ day-edge untested (Tuesday regime Jan–Aug 2025 is the decisive OOS test).
- PE leg = 78% of profit ⇒ accidental delta bias.

V5 fix (Tradetron-native):
- Wings via `Find Strike(ltp=15-25%-of-ATM-premium, lesser)` or `Delta 0.12/-0.12` live.
- %-of-credit exits: `PNL ≤ -0.35 × sum(CE_entry, PE_entry)`, `PNL ≥ +0.50 × sum`, wrapped in `Multiplier`.
- AND-grouped Max-Profit trail: `(Max Profit ≥ 1500) AND (PNL ≤ Max Profit - 400)`.
- `Leg Exit` per-leg blow-up (100% SL on shorts) to balance CE/PE contribution.
- Entry 09:45–10:15 + 0.6% gap filter + `Position Detail(qty)==0` guard.
- Execution: Immediate Fill / LTP + 3-5 rev + 2 ticks + 10s + Execute-at-Market + tranch 25%×4 + Exit Shorts First + Exit at Market.
- Capital display 1.5L / liquid 4L live; backtest 1-min Close Intraday Net-of-costs LCM lot-proofed.
- Judge on expectancy/trade, PF, max DD duration, 21d rolling Sharpe, weekday split (NOT ROI/CAGR/Calmar).

---

## D. DECODE #1 — **NEW** BankNifty Supertrend Crossover (from user's 3 screenshots this session, 2026-08-26)

Source video: Pradeep Kumar Singh, "Tradetron: Find Strike — Strike Selection Methods" ([YouTube](https://www.youtube.com/watch?v=Ia4F6laAqs8)).
Cited by user as "the person calls it a crossover condition for CE option".
Three Tradetron screenshots decoded verbatim ([MntG1Mj1](https://www.genspark.ai/api/files/s/MntG1Mj1), [e6QqN15l](https://www.genspark.ai/api/files/s/e6QqN15l), [Fr8jJ6bT](https://www.genspark.ai/api/files/s/Fr8jJ6bT)).

### True entry logic — translated to Tradetron logic (6 AND rows)

| # | Block (verbatim from image) | What it actually does |
|---|---|---|
| 1 | `Time (NSE) >= Number (925)` | Entry floor 09:25 IST |
| 2 | `Time (NSE) <= Number (1458)` | Entry ceiling 14:58 IST |
| 3 | `Net Quantity (Traded Instrument Name (Entry, instrument, NIFTY BANK, 1, 1, 1)) == Number (0)` | Leg-1 (CE) net qty must be 0 → no double-entry |
| 4 | `Net Quantity (Traded Instrument Name (Entry, instrument, NIFTY BANK, 2, 1, 1)) == Number (0)` | Leg-2 (PE) net qty must be 0 |
| 5 | `Position(CLOSE(Symbol(Instrument Name(NFO:NIFTY BANK,…), 1m, All)), -1) > Position(SUPERTREND(Symbol(Instrument Name(NFO:NIFTY BANK,…), 1m, All), 5, 2), -1)` | **CE leg's price closes ABOVE its Supertrend(5,2) on the prior 1-min candle → buy long CE** |
| 6 | `Position(CLOSE(Symbol(Instrument Name(NFO:NIFTY BANK,…), 1m, All)), -2) < Position(SUPERTREND(Symbol(Instrument Name(NFO:NIFTY BANK,…), 1m, All), 5, 2), -2)` | **PE leg's price closes BELOW its Supertrend(5,2) two candles back → confirms CE cross UP (the same bearish turn for PE = the bullish turn for CE)** |

### Formula Builder block (Find Strike)

`Find Strike (NIFTY BANK, Select Expiry(week, 0), ltp, Number(100), CE, lesser)`

→ Pick the **CE option closest to premium ₹100 whose LTP is currently ≤ ₹100** (i.e., `lesser` of the ₹100 mark). Used as the Wing-strike selector on BankNifty after the Supertrend confirms a long CE entry.

### What this strategy ACTUALLY is — unpacked

- IV: NIFTY BANK 1-minute candle on the **CE option**'s own premium series, not on the underlying index. (TRAP — most YouTube tutorials paint Supertrend on spot/futures; this one paints it on the option premium.)
- Supertrend parameters: period **5**, multiplier **2**. (Very tight — needs paper validation; anything above 100k/day on BANKNIFTY options in 1-min is noisy.)
- The crossover is on the **CE premium > Supertrend(5,2)** = bullish leg entry.
- The PE row **position=-2** (two candles back) on Supertrend(5,2) = confluent bearish turn on the put side = confirms the bullish CE cross.
- Find Strike picks the **CE option at premium ≈ ₹100** as the protective/hedge leg.
- The CE leg is being entered (Bought), not sold — this is the **opposite direction** of our V5 Sensex Iron Fly (where CE is sold.).
- it is a **directional long-CE + hedge-cheap-CE(₹100)** play, NOT theta harvest.

### Difference from V5 Sensex Iron Fly entry logic

| | V5 Sensex Iron Fly | Decoded BankNifty Strategy |
|---|---|---|
| Direction | SHORT straddle + cheap wings (theta harvest) | LONG CE + cheap CE hedge (directional) |
| Underlying indicator? | No — pure time + structure | Yes — Supertrend(5,2) on the CE option premium |
| Strike logic | Premium-targeted wings (defensive) | Buy nearest strike whose premium < ₹100 |
| Re-entry guard | `Position Detail(qty)==0` once | `Net Quantity==0` per leg (more granular) |
| Entry window | 09:45–10:15 | 09:25–14:58 (all day, bar 2 candles) |
| Hedge idea | Get wings to actually cost money | Get a cheap "lottery" hedge |

→ **Conclusion:** This BankNifty strategy is a long-premium directional + cheap hedge dealer, structurally opposite to our V5 theta. Useful ONLY as an entry **edge** for the CE leg of an asymmetric iron-fly spinoff, never as a direct replacement. Don't cargo-cult its Supertrend on CE premium into the SENSEX iron fly — they trade different things.

---

## E. KNOWLEDGE BASE INVENTORY (cross-link)

Files in Hub (read first when resuming):
1. `tradetron-mastery.md` — 89 lines, full keyword scope + backtest engine truth.
2. `Tradetron_platform_notes.md` — 115 lines, Repair Once/Continuous, % SL pattern, debug workflow.
3. `tradetron_videos_learned.csv` — 122 rows of decoded Tradetron tutorials (core).
4. `Tradetron_Video_Learnings.xlsx` — 30 detailed decodes (Advanced Wizard 5-part, CAS, lot-size LCM, Immediate Fill, etc).
5. `SENSEX_0DTE_Variants_V1_V2_V3.xlsx` — 7 sheets, original variants.
6. `SENSEX_0DTE_Backtest_Protocol.xlsx` — 7 sheets, regime-sliced walk-forward plan.
7. `SENSEX_0DTE_Master_Strategy_V4.xlsx` — 11-sheet merged reference (2026-08-25).
8. `SENSEX_0DTE_Strategy_V5_Tradetron_Mastery.xlsx` — 7-sheet Tradetron-native spec (this session).
9. `TRADETRON_MASTERY_KNOWLEDGE_BASE.md` — 7006-char distilled reference.
10. `brain2.md` (this file) — persistent memory index.

---

## F. BRAIN 2 — Operation rules

- **Read first** on any new Algo Hub conversation.
- **Append-only** — never overwrite prior session entries; add dated sections at the bottom.
- **Save to AI Drive** at path `/Rishabh_Jain_Algo_Memory/brain2.md` (durable across sessions); sandbox copies are ephemeral.
- **Re-load from AI Drive** when `aidrive_tool` action=`get_readable_url` returns a path.
- **Update cycle**: every new technical discovery / new software update / new regulator note triggers a Brain 2 patch.
