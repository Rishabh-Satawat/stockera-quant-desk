=========================================================
TASK 1 — TRADETRON MCP CONNECTION + KEYWORD GROUND TRUTH
Deliverables: 19_TT_MCP.md · 00_INDEX.md · 02_KEYWORDS.md
              12_KEYWORD_LEDGER.md
Supersedes the previous Task 1 brief in full. That brief
told you to reconstruct the keyword surface by crawling
docs and YouTube. Do not do that. An authoritative source
now exists and this brief points you at it.
=========================================================

ROLE
Senior algorithmic-trading systems documentarian with
operational expertise in Tradetron and Indian F&O
microstructure. You write for one reader: a downstream AI
agent that will use your output as its ONLY source of truth
when building Tradetron strategies. That agent cannot see
the UI. It knows nothing you do not write down. Every
ambiguity you leave becomes a silent failure in a live
system with real capital at risk.

WHY THIS TASK EXISTS
On 2026-08-27 a fabricated keyword ("Get Var") reached the
operator and cost a build attempt. Note: the real keyword
appears to be "Get Runtime" — confirm the exact label.

---------------------------------------------------------
EVIDENCE TAGGING — an untagged claim is a defect
---------------------------------------------------------
[V] Verified   — returned by a Tradetron MCP tool, or read
                 in an official Tradetron page. Cite the
                 tool name or the full URL, plus any
                 "updated on" date shown.
[O] Observed   — from an operator screenshot or a backtest
                 report. Cite which one.
[I] Inferred   — reasoning shown in one explicit sentence.
[U] Unverified — MUST appear in OPEN ITEMS.

MCP-returned data outranks the docs page, which outranks
QnA threads, which outrank YouTube. Where they disagree,
say so loudly and record BOTH values. Contradictions are
higher-value output than confirmations.

STALENESS: any claim about the backtest engine sourced
before 25-Aug-2026 is automatically [U] — FastBT replaced
the previous engine that date and is now the only engine.
Any claim about lot sizes, expiry weekdays, session timings
or charges sourced before 2025 is [U] pending an exchange
circular.

NEVER INVENT a keyword name, argument, dropdown label or
rendered string. If you cannot confirm exact spelling,
write "[U] EXACT UI LABEL UNCONFIRMED — verify in builder"
and move on. A wrong keyword is worse than a gap, because
the reader will trust it.

EXACT STRINGS ONLY. Reproduce rendered output verbatim,
including every space, quote and comma. Trailing-comma
variants are functionally significant. Never normalise.

---------------------------------------------------------
STEP 1 — CONNECT
---------------------------------------------------------
Register the Tradetron MCP server:
  Server URL : https://mcp.tradetron.tech/mcp
  Transport  : Streamable HTTP
  Auth       : OAuth. A Tradetron login page opens; the
               operator signs in there. No API key, no
               token, no request header.
  Header     : EMPTY

Tradetron documents ChatGPT, Gemini, Grok and Claude and
states any MCP-capable app works with the same URL. This
host is Genspark, which is NOT on their tested list —
treat success as unproven until it connects. If OAuth
fails, capture the exact error verbatim and STOP; do not
work around it, do not substitute a scraped source.

Read-only tools (keyword lookup, docs, plans, brokers,
calendar, draft validation) work BEFORE sign-in. Saving
strategies and reading the operator's own logs, deployments
and P&L require the OAuth connection. If sign-in is
blocked, you can still complete most of this task — say
which parts are degraded.

---------------------------------------------------------
STEP 2 — ENUMERATE THE TOOL SURFACE
---------------------------------------------------------
List EVERY available tool VERBATIM with its full input
schema, every parameter, type and required/optional flag.
Do not normalise names. Do not assume the published list of
47 is what you actually received — report the count you
observe and diff it against the published list at
tradetron.tech/mcp-tools. A missing tool is a finding.

Write to 19_TT_MCP.md, grouped by job: build, validate,
backtest, edit, paper-deploy, debug, performance,
catalog/lookup, account.

Mark PROHIBITED BY DESK POLICY:
  - tt_deploy_strategy_paper — paper only, still requires
    explicit operator approval each time, never autonomous
  - any tool that modifies a DEPLOYED strategy
  - any list-modification tool touching live watchlists
The MCP cannot place live orders or move funds. Verify that
claim against the tool schemas rather than trusting the
marketing page, and report what you find.

---------------------------------------------------------
STEP 3 — HARVEST THE KEYWORD CATALOG
---------------------------------------------------------
This is the core of the task.

3.1 Call tt_list_keywords_by_category for EVERY category.
    Enumerate categories first; do not guess them. Report
    the total keyword count returned.

3.2 Call tt_lookup_keyword on EVERY keyword returned. Not a
    sample. Every one. Capture exactly what comes back:
    argument list IN ORDER, allowed values, types,
    defaults, and any usage note. Argument ORDER is where
    silent breakage comes from — Tradetron says so in their
    own agent-rules file.

3.3 Call tt_get_tradetron_quickstart and
    tt_get_authoring_reference. These carry the grammar and
    schema rules. Capture them in full; do not summarise.

3.4 Cross-reference tradetron.tech/keyword/documentation.
    That page is long and lazy-loads; fetch by byte offset
    until you reach the end. Its purpose here is to find
    keywords the MCP did NOT return, and prose explanation
    the MCP does not carry. Report the count on that page
    against the MCP count and state coverage %.
    Where the two disagree, record BOTH and flag it.

3.5 Only for gaps still open after 3.1-3.4, consult
    help.tradetron.tech/en/category/keywordsstrategy-logics
    -1miek11/ and qna.tradetron.tech threads 883, 884, 890,
    1254, 2362. Mark each answer STAFF or COMMUNITY with
    its date. Do NOT pull YouTube transcripts in this task
    — speech does not capture screen state and the yield is
    poor now that an authoritative catalog exists.

---------------------------------------------------------
02_KEYWORDS.md — grouping and required fields
---------------------------------------------------------
Group: time & date · price/LTP · PNL & max-profit · position
state · math & logic · greeks · OI & volume · runtime &
variables · expiry · strike selection · candle patterns ·
indicators.

For EVERY keyword record:
 - exact name, exact argument list in order
 - LEGAL CONTEXTS: Entry / Repair Once / Repair Continuous /
   Universal Exit / Set Exit / Strike Fx / Qty Fx /
   Expiry Fx / Initialise Variables. A keyword legal in one
   and not another is a top-tier failure mode.
 - NESTING: what may nest inside it; what it nests inside.
   Several keywords are legal only inside others — e.g.
   most indicators must sit under the Position keyword;
   Find Strike is used in Strike Fx.
 - MULTIPLIER BEHAVIOUR: does the value scale with the
   deployment multiplier? Fixed-rupee thresholds do NOT.
   Flag every scaling trap — this has already bitten the
   operator live.
 - LOT-SIZE SENSITIVITY: FastBT applies the HISTORICAL lot
   size in force on each trade date from exchange
   circulars. NIFTY went 75-50-25-75-65. A fixed-rupee
   threshold therefore means a different move in different
   years. Flag every keyword this distorts.
 - FastBT SUPPORT: YES / NO / PARTIAL. FastBT declines
   constructs it cannot faithfully simulate rather than
   mis-booking them; ~34% of real traded volume is still
   not honestly backtestable (down from 44%). Determine
   whether OUR keyword set sits inside the supported share.
   tt_check_backtestability may answer this directly —
   check whether that tool accepts a keyword or only a
   whole strategy.
 - SWEEPABILITY: is a numeric argument here discoverable by
   tt_backtest_sweep? Confirmed rule: only LITERAL numbers
   inside the strategy are sweepable; 0, 1 and -1 are
   skipped as flags; runtime-computed or variable-held
   values are invisible.

---------------------------------------------------------
PRE-SEEDED QUIRKS — confirm or refute. Do not rediscover.
Four of these are already partly settled; your job is to
close them, not re-open them.
---------------------------------------------------------
Q1 "Get Var" is NOT valid. Two real keywords appear to
   exist: "Get Runtime" (fetches a runtime variable, string
   or number) and "Get Runtime Number" (numeric only,
   introduced for places where a string is illogical).
   Confirm exact labels via tt_lookup_keyword and give the
   verbatim rendered string for reading an option price —
   expected form LTP( Instrument Name(...) ).

Q2 LIKELY REFUTED — the operator's notes say Instrument
   Name can only resolve ATM off FUTURES and that only
   Strike Fx resolves off SPOT, citing QnA 2362. But the
   keyword documentation lists "ATM SPOT" as its own
   keyword and states it "can also be used in the
   Instrument Name keyword to fetch an instrument based on
   the spot-based ATM value." SETTLE THIS. It is the
   highest-value item in the task: the operator's SENSEX
   structure carries a workaround that may be unnecessary.
   Report which is true, when it changed if it changed, and
   what the operator should now do differently.

Q3 CONFIRMED — Find Strike maintains 50 strikes above and
   below ATM, ATM computed from the CURRENT DAY'S OPENING
   price and fixed for the day; out-of-range returns "none"
   silently; with 'any' selected it returns the nearest
   available. Your job is to add what the operator does NOT
   have: the per-index expiry support matrix. Documentation
   states NIFTY 50 works on current week / next week /
   current month / next month; NIFTY BANK and FINNIFTY on
   CURRENT MONTH AND NEXT MONTH ONLY — no weekly; SENSEX on
   current week and current month. Not compatible with MCX
   or MIDCP. Equity options unreliable. CONFIRM this matrix
   and flag loudly if it constrains any structure the
   operator trades. Also document delta mode fully: decimal
   values, PE must be NEGATIVE, illiquid-strike warning.

Q4 find_traded_instrument cannot be referenced by a leg
   firing on the SAME entry condition — the referenced leg
   has not filled at resolution time and it returns None.
   Legal only from Repair Once or a later entry. Confirm.

Q5 Runtime variables — HIGHEST-VALUE OPEN QUESTION.
   Capture at TRIGGER or at FILL? Persistence across
   run_counter? Manual reset required? Available in Entry,
   Repair AND Set Exit? Related confirmed fact: "Init Var"
   runs ONCE, so any change to its value after deployment
   takes effect only after the run counter changes. This
   determines whether credit-relative exit thresholds are
   buildable at all. If the MCP cannot answer it, say so
   and hand it to Task 4 rather than guessing.

Q6 Top-level AND/OR toggle: exact UI label, and confirm
   that an exit block set to AND makes mutually exclusive
   rows permanently unreachable. This was a live fatal bug
   in the operator's build.

Q7 CONFIRMED — India VIX is a condition input and FastBT
   breaks every report down by VIX regime. Supply the exact
   instrument string and which contexts accept it.

Q8 CONFIRMED VERBATIM — sweep discovers only literal
   numbers; 0, 1 and -1 skipped; runtime/variable values
   invisible; max 4 axes x 10 values x 16 combinations;
   ₹20 per variant. State plainly what this costs us: a
   credit-relative threshold expressed as a Math Operation
   becomes UN-SWEEPABLE. Give the operator the workaround
   if one exists.

Q9 NEW — Tradetron's own agent-rules file warns: never name
   a runtime variable after a Tradetron keyword. Names in
   the "Entry…" and "LastRepaired…" families ARE keywords.
   Storing a value under one of those names and reading it
   back finds nothing, returns empty, and leaves the
   condition PERMANENTLY TRUE, silently. Enumerate every
   reserved name in those families. This is a live-money
   footgun and it is not in our knowledge base.

Q10 NEW — the same file states the general failure mode: a
   wrong or missing argument usually does NOT error. It
   returns nothing, the containing condition then evaluates
   true forever or never fires, and it validates clean,
   saves clean and reads back clean in the builder. Confirm
   and document which keywords are most exposed.

---------------------------------------------------------
12_KEYWORD_LEDGER.md — the machine-checkable index
---------------------------------------------------------
One row per keyword, append-only:
 name | args in order | legal contexts | rendered string |
 tag | source (tool name or URL) | source date |
 multiplier-scales? | lot-size-sensitive? | FastBT support |
 sweepable? | quirks | last verified

Every future build diffs against this file.

---------------------------------------------------------
STOP AND REPORT — do not start Task 2
---------------------------------------------------------
a) files written, with paths
b) MCP connection: succeeded or failed, with the verbatim
   error if it failed
c) tools enumerated: count observed vs 47 published, and
   the diff
d) keywords documented / total found, per source, with
   coverage % — state it explicitly, a partial crawl
   silently produces a partial bible
e) [V]/[O]/[I]/[U] counts per file
f) verdict on each of Q1-Q10
g) TOP 15 [U] ITEMS AS A NUMBERED SCREENSHOT CHECKLIST:
   for each, the exact panel, which dropdown to open, and
   what must be visible in frame. The operator has the UI;
   you do not. This is the single most valuable output of
   this task.
h) ANYTHING THAT CONTRADICTS EXISTING OPERATOR MATERIAL,
   flagged loudly and separately.
i) WHAT I COULD NOT VERIFY — every [U] and every failed
   retrieval, with what you tried. A deliverable, not an
   apology.

SELF-REVIEW (mandatory section, must not be empty)
Re-read your own output as a hostile reviewer hunting for
the error that costs money. Specifically: any [V] that is
really [I]; any keyword or rendered string not traceable to
a tool response or a cited page; any number you did not
read directly from a source. Show what you corrected. If
you found nothing, you did not do this pass.

HUB WRITE PROTOCOL
Emit durable content in fenced blocks headed
">>> HUB WRITE: <filename>". "(append)" means add, never
overwrite. Negative results are deliverables — a tool that
does not exist, a keyword that proved fabricated, a
retrieval that failed. Log them to 13_FAILURE_LOG.md.

CLOSE WITH
"What should we do next, and why that before anything
else?" — one primary action, its cost, its binary pass/fail
gate, and what it unblocks.

There are ~11 tasks queued behind this one. Do not drift
into them.
