# Tradetron MCP — AI Memory

## Purpose of this memory file

This file consolidates the public Tradetron MCP reference and its companion instruction file into a retrieval-oriented knowledge base. It distinguishes what Tradetron explicitly documents from analytical implications and from claims that should be independently verified before relying on them.

## Source scope and canonicalization

| Logical source | URL | Review result |
|---|---|---|
| MCP tool reference | [tradetron.tech/mcp-tools/](https://tradetron.tech/mcp-tools/) | Long public HTML reference; describes 47 tools, staged workflows, examples, debugging limits, connection, and guardrails. |
| Drop-in instructions | [tt-mcp-instructions.md](https://tradetron.tech/mcp-tools/tt-mcp-instructions.md) | Public Markdown rules file intended for persistent AI instructions. |
| Related onboarding | [TT Assistant](https://tradetron.tech/tt-assistant/) | Cross-reference reviewed in the companion memory file. |

The MCP page contains internal anchors for the tool inventory and examples, a TT Assistant link, the downloadable Markdown instruction file, a Universe link, FastBT, Build with Claude, Features, and Pricing. The page’s “Browse the tools” and “See real responses” controls are in-page anchors rather than separate products.

## Core product model

> The Tradetron MCP is presented as the connector that turns a conversational AI into a working quant desk on a user’s Tradetron account. [1]

Tradetron describes MCP as the action layer between an AI conversation and Tradetron’s strategy platform. The user speaks in ordinary language; the AI chooses among Tradetron tools; the tools look up authoritative platform concepts, validate structured requests, create or edit strategy templates, run backtests, inspect paper/live deployment information, and answer account or product questions. The page claims **47 tools**, **8,500+ resolvable underlyings**, operation on the user’s own AI plan, and zero lines of code. [1]

The central lifecycle is **Explore → Build → Run**.

| Stage | Intended use | Example questions or actions |
|---|---|---|
| Explore | Grounded product and market-catalog questions that do not require a connected account. | Plans and pricing, broker support, instrument support, market-open status. |
| Build | Convert a natural-language idea into a validated strategy template. | Create a weekly short straddle; specify an indicator entry and time exit; backtest and save. |
| Run | Operate and review a book after creation. | Diagnose why a strategy did not trade, apply a surgical hedge edit, rank strategies by damage. |

The important conceptual distinction is that the AI is the conversational layer, while Tradetron MCP is the operational layer. A fluent answer alone is not equivalent to a saved or executable strategy; the documented workflow requires lookups, validation, creation, read-back, and user review.

## Tool inventory by job

### Build

The Build group is described as plain English to a real strategy. It can retrieve worked patterns, resolve keywords, emit an exact template, create a strategy in the user’s account, and handle large multi-set books. The named tools are `tt_create_strategy`, `tt_create_strategy_chunked`, `tt_get_sample_strategy`, `tt_get_tradetron_quickstart`, and `tt_get_authoring_reference`. [1]

### Check First

This group is intended to catch mistakes before they cost money. It validates strategy specifications against a locked schema, identifies wrong types and unknown keywords, catches silently dropped legs locally, and security-checks Custom Python. The named tools are `tt_validate_markdown`, `tt_validate_python`, `tt_lookup_keyword`, `tt_find_keyword`, and `tt_list_keywords_by_category`. [1]

### Backtest

The Backtest group runs historical tests from chat, returns a FastBT report link, supports parameter sweeps, polls long runs, and checks whether a strategy is backtestable. The named tools are `tt_backtest_strategy`, `tt_backtest_sweep`, `tt_backtest_status`, and `tt_check_backtestability`. The MCP page states a flat ₹20 backtest price and 6.5 years of audited history; the FastBT memory file provides the more detailed context and vendor-claim caveats. [1] [2]

### Edit

The Edit group supports fetching a strategy, scalar updates, whole-set replacement, and surgical patches to one leg or condition. It is intended to change one thing rather than rebuild everything. Structural edits are described as round-trip verified, with silent drops failing loudly. The named tools are `tt_get_strategy`, `tt_update_strategy`, `tt_apply_strategy_patch`, `tt_export_strategy`, and `tt_list_editable_fields`. [1]

### Paper Trade

`tt_deploy_strategy_paper` is described as deploying a strategy to paper trading against real market data, never directly to live trading. The page emphasizes ownership checks so the tool operates only on the user’s own account. [1]

### Debug Live

The Debug Live group fuses deployment information, the engine notification log, and the broker log into a diagnosis. It also provides direct notifications, broker logs, deployed-strategy lists, deployment details, and run counters. The named tools are `tt_diagnose_strategy`, `tt_get_strategy_notifications`, `tt_get_strategy_broker_log`, `tt_get_my_deployed_strategies`, `tt_get_my_deployed_strategy_detail`, and `tt_get_strategy_counters`. [1]

### Performance

Performance tools provide descriptive P&L and portfolio reporting rather than buy/sell advice. The page names strategy performance, portfolio reports, report exports, and report templates: `tt_strategy_performance`, `tt_portfolio_report`, `tt_export_reports`, and `tt_report_template`. [1]

### What is tradable

The catalog tools provide deterministic broker, symbol, exchange, and list lookups rather than relying on model training-data guesses. They include broker support, broker lists, integration guides, underlying support, underlying lists, list search, list retrieval, and list modification. [1]

### Answers and account

The final group covers grounded Tradetron Q&A, market calendars, profile, subscription, plans, marketplace subscriptions, and human support escalation through Crisp. The named tools are `tt_ask_tt`, `tt_market_calendar`, `tt_get_my_profile`, `tt_get_my_subscription`, `tt_list_plans`, `tt_get_my_strategy_subscriptions`, `tt_open_crisp_conversation`, `tt_check_crisp_response`, and `tt_reply_to_agent`. [1]

## Three documented interaction patterns

### Build flow

The example request is a NIFTY weekly short straddle with 30% profit exits and a 3:15pm square-off. The documented tool sequence is sample retrieval → Markdown validation → creation. The example response returns an ID, name, edit URL, dry-run verification, and validation warnings. The page says the resulting template is ready for inspection in Advanced Strategy Builder and that nothing was saved until validation was clean. [1]

### Debug flow

The example asks why a short straddle did not trade. The diagnosis card separates the engine decision from the broker result: the entry condition fired, sell orders were placed, and the broker rejected them because available margin was insufficient. The page’s design lesson is that the user should repair the faulty layer rather than edit strategy logic blindly. [1]

### Review flow

The example lists six deployments with Active, Paused, Error-Execution, and Exited states across live and paper modes. The user can then name a strategy and request diagnosis, performance, or management information. [1]

## What the debug log does and does not contain

Tradetron states that its diagnostic path reads the live engine notification log itself, not a separate MCP-only summary. The stream is filtered to the requested strategy and ownership-gated. It can show entries and exits with instrument and side, the condition that fired and when, terminal status, engine errors and tracebacks, broker rejections or blocks such as RMS/margin/token/auth issues, order statuses, and broker-side reasons. [1]

It cannot show the evaluated indicator value at every candle, the live left- and right-hand operands compared by a condition, or values calculated only in memory per tick. The reason given is architectural: the engine persists the decision, not all arithmetic that led to the decision. The page says operand capture is on the roadmap. [1]

## Connection and permissions model

The public MCP endpoint shown by the page is:

```text
https://mcp.tradetron.tech/mcp
```

The page describes OAuth on Tradetron’s own login page. It says the AI does not see the password and that the permission can be revoked. Read-only plans, broker, documentation, and draft-related capabilities are described as available before sign-in, while saving strategies and reading personal logs, deployments, and P&L require the OAuth connection. [1]

The public page does not authorize a connection merely by exposing the URL. A real implementation still requires a user-controlled AI client, OAuth consent, and appropriate account permissions.

## Persistent instruction file: what it teaches the AI

The companion file is intended to be saved once so that the AI reads the same operational rules every session. It can be placed in Claude Code as `CLAUDE.md`, in Claude project instructions/project knowledge, in ChatGPT custom instructions or a project, or in another AI’s startup context. [2]

### Behavioral discipline

The instructions tell the AI to stress-test ideas rather than agree automatically, avoid echoing the user’s framing, be direct and concise, and avoid praise without concrete reasoning. This is a meta-rule for reducing confirmation bias in strategy discussions.

### Deployed-template safety

The most consequential rule is that a deployed template and its running deployment share one definition. Editing a deployed template is therefore treated as changing live logic. The file says to edit a non-deployed template in place, but to make a copy before changing something deployed, subscribed, or public. It warns against creating unnecessary near-duplicate templates and says to use scope and a `DO NOT CHANGE` line instead.

The file also distinguishes template IDs from deployment SIDs. It warns not to undeploy and redeploy to apply an edit, because that can lose the deployment and open positions. It calls out three operational subtleties: a set whose entry has already fired will not re-enter merely because its entry was tightened; closing an already-held leg requires making that same set’s exit true; and adding a sell leg in another set may open a separate short rather than close an existing position. [2]

### Clarify before building

The AI must ask about exchange and exact symbol spelling, expiry for every leg, exchange clock, lots or quantity, whether rules fire once or repeat, product type, and exit behavior. It must stop if two interpretations would produce materially different strategies. [2]

### Read references before authoring

The instructions require the AI to read the current quickstart, the relevant authoring reference, every keyword’s exact parameters and argument order, and the exchange reference. This is designed to prevent plausible-looking but semantically wrong templates. [2]

### Review-first creation sequence

Before writing, the AI must show the strategy Markdown, a plain-English summary, and exactly what differs from the current version. It must wait for approval. The mandated technical sequence is: validate Markdown, dry-run/build without saving, create using the dry-run token, and fetch the saved strategy back to show the stored version. The file explicitly says validation is not proof of correctness because the stored form is what the engine runs. [2]

### Silent-failure warning

The file highlights that a wrong or missing argument may validate and save without an explicit error. The resulting condition may be empty, permanently true, or never fire. Runtime checking and read-back are therefore treated as mandatory rather than optional polish. [2]

### Post-creation checks

The user should open the template in Advanced Strategy Builder and read every condition and leg, then paper-deploy and confirm that the intended conditions fire with expected values. The file rejects presenting a first draft as final and expects iterative correction. [2]

## Operational interpretation

The MCP is best understood as a **controlled strategy lifecycle interface**, not as an autonomous trading oracle. Its strongest design themes are schema validation, authoritative lookups, ownership boundaries, paper-first workflow, transparent failure diagnosis, and explicit user control over live deployment. The practical risk is not only a tool failure; it is a semantically wrong strategy that passes syntax validation. The instruction file’s insistence on clarifying questions and stored-version read-back addresses that risk.

## Safety and limitations

The public pages state that MCP can create/edit templates, backtest, paper-deploy, and read diagnostics, but cannot place live orders, take a strategy live, transfer funds, or provide investment advice. Performance figures and examples are described as illustrative or descriptive and not predictive. Trading securities and derivatives carries substantial risk. [1] [2]

## References

[1]: https://tradetron.tech/mcp-tools/ "Tradetron MCP tool reference"
[2]: https://tradetron.tech/mcp-tools/tt-mcp-instructions.md "Drop-in AI instructions for working with Tradetron MCP"
[3]: https://tradetron.tech/tt-assistant/ "Tradetron TT Assistant"
[4]: https://tradetron.tech/fastbt/ "Tradetron FastBT"
