=========================================================
TASK 2 — STRATEGY SCHEMA + CONDITION GRAMMAR
Deliverables: 28_TT_SCHEMA_SPEC.md · 04_CONDITION_LOGIC.md
              27_TT_IMPORT_FIDELITY.md
Prerequisite: Task 1 complete, 12_KEYWORD_LEDGER.md exists.
Inherits all evidence-tagging, self-review, hub-write and
closing rules from Task 1. Do not restate them; obey them.
=========================================================

OBJECTIVE
Task 1 gave us the vocabulary. This task gives us the
GRAMMAR: how a Tradetron strategy is structured, how
conditions nest and combine, and what survives a
round trip through export and import. Without this the
agent knows words but cannot form sentences.

WHY IT MATTERS
tt_create_strategy takes a strategy specification and
validates it against a locked schema. We need to know that
schema precisely — not approximately. Documentation
reconstructed by inference is APPROXIMATELY right, which is
the worst possible quality level for something that places
orders.

---------------------------------------------------------
2.1 THE AUTHORING REFERENCE IS THE PRIMARY SOURCE
---------------------------------------------------------
Call tt_get_authoring_reference for EVERY topic it exposes.
Enumerate the topics first; do not guess them. Call
tt_get_tradetron_quickstart. Call tt_get_sample_strategy
for every pattern available.

Capture in full. Do not summarise, do not paraphrase, do
not "clean up" formatting. The exact strings matter.

From these, extract and write up:
 - the top-level structure of a strategy and every object
   type within it
 - how SETS work: what a Set is, how entry / exit /
   adjustment blocks relate, how Set No / Condition No /
   Leg No are assigned, and how leg BUILD ORDER determines
   leg numbering
 - the full condition grammar: how rows nest, how AND/OR
   and grouping are represented, the complete operator set,
   comparison types
 - how legs are defined: instrument, expiry, option type,
   strike, quantity, product type, buy/sell
 - how strike selection is encoded in each of its modes —
   ATM offset, ATM-SPOT offset, premium-based, delta-based,
   absolute strike — with a real worked example of each
 - how quantity, lots and the deployment multiplier
   interact
 - how runtime and custom variables are declared and
   referenced
 - how a custom Python block is embedded, and its
   boundaries
 - what tt_validate_markdown rejects, and the exact wording
   of its error messages where you can obtain them

---------------------------------------------------------
2.2 ROUND-TRIP FIDELITY GATE — BLOCKING
---------------------------------------------------------
The operator will supply a real exported strategy: his live
SENSEX weekly iron fly. Nothing generated may be trusted
until this test is documented.

Procedure, written so a non-coder can run it:
 1. export the strategy (tt_export_strategy, or the UI
    Export button — document BOTH paths and whether they
    produce the same artefact)
 2. import it back unchanged as a NEW strategy
 3. compare the two side by side in the builder

Determine what SURVIVES and what is LOST across:
 condition logic · leg definitions · strike-selection rules
 · expiry selection per leg · deployment settings · broker
 mapping · lot sizing · multiplier · runtime and custom
 variables · Python block · scheduling · notification
 config · backtest settings · re-entry counters

Write 27_TT_IMPORT_FIDELITY.md as an explicit
SURVIVES / LOST / UNKNOWN table. No prose verdict without
the table behind it.

Note Tradetron's own claim that structural edits are
"round-trip-verified — silent drops fail loud". Test that
claim rather than repeating it.

---------------------------------------------------------
2.3 THE NEVER-FROM-SCRATCH RULE
---------------------------------------------------------
Establish this as desk policy and write it into the spec:

The agent must NEVER author a strategy from scratch when a
comparable baseline exists. It takes a real exported
baseline and EDITS it — strikes, timeframes, thresholds,
leg counts — so the structure is valid by construction.
Every generated strategy ships with a DIFF against its
baseline so the operator sees exactly what changed.

Rationale to record: a from-scratch strategy that is subtly
malformed is the dangerous failure mode. It validates
clean, saves clean, reads back clean in the builder, and
behaves differently than intended. Tradetron's own
documentation confirms a wrong or missing argument usually
returns nothing rather than erroring, leaving the condition
permanently true or permanently false — silently.

Then state honestly where this rule cannot apply and what
the fallback is.

---------------------------------------------------------
2.4 THE EDIT-SAFETY RULES — write these into 04, verbatim
---------------------------------------------------------
From Tradetron's own agent-rules file. Verify each against
tool behaviour or documentation, tag accordingly, and
record the operational consequence:

 - A deployed template and its running deployment share one
   definition. Editing a deployed template changes LIVE
   logic immediately; set entries and exits execute
   intraday rather than waiting for a reload.
 - Not deployed → edit in place. Deployed → copy first,
   edit the copy.
 - A Set whose entry has fired and not exited will NOT
   enter again. Tightening that set's entry does nothing to
   the position it already holds.
 - To close a held leg, make that same set's OWN exit
   condition true. A sell leg in a DIFFERENT set opens a
   separate short instead of closing anything.
 - Never undeploy and redeploy to apply a change — that
   loses the deployment and its open positions. Edit the
   template id (9xxxxx), never the deployed sid (30xxxxx).

Then answer: which of these are enforced by the MCP, and
which are merely conventions the operator must remember?
Anything unenforced needs a checklist entry.

---------------------------------------------------------
2.5 THE FOUR-STEP CREATION PROTOCOL
---------------------------------------------------------
Document and adopt: validate markdown → dry run without
saving → create using the dry-run token → FETCH THE
STRATEGY BACK and show the stored version.

Step 4 is not optional. The stored form is the only thing
the engine runs and it is not always identical to what was
submitted. "It validated" is not evidence that it works.

Confirm each step maps to a real tool with real parameters,
and give the exact call sequence.

---------------------------------------------------------
STOP AND REPORT
---------------------------------------------------------
a) files written
b) authoring-reference topics enumerated and captured,
   with coverage %
c) the SURVIVES / LOST / UNKNOWN table, complete
d) any place the authoring reference contradicts
   12_KEYWORD_LEDGER.md — flagged loudly, both values kept
e) a WORKED EXAMPLE: the operator's iron fly expressed in
   the strategy specification format, annotated line by
   line, every keyword cross-referenced to its ledger row.
   This is the proof that the grammar is understood.
f) confidence statement: could a competent agent build a
   NEW multi-leg strategy from this document alone, without
   the UI? If no, what is missing? Be blunt.
g) SELF-REVIEW section, per Task 1 rules.
