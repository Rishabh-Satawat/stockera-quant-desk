# Tradetron platform mastery — deep reference
Built 2026-08-25 from Tradetron official keyword docs, help centre, QnA forum, blog, and YouTube channel material.
(source: target=#channel-fbdaec98:ch_946f012149a777b858fc5db5794f80b4 comet_message_id=3156584 date=2026-08-25 sender=Rishabh Jain/41301041-ba21-4d36-a622-43760e97e3d6)

## THE ARCHITECTURE — 5 blocks, and scope is everything
A strategy = Sets. Each Set has: **Entry condition** -> **Positions** -> **Set Exit**, plus
**Repair Once** / **Repair Continuous** blocks, and ONE strategy-wide **Universal Exit**.
Scope rules (the #1 source of bugs):
- **Universal Exit** = whole strategy, exits everything, increments the run counter.
- **Set Exit** = that set's legs only.
- **Repair Once** = fires ONE time, partially modifies the position (per-leg SL, hedge add).
- **Repair Continuous** = keeps re-firing while condition true (rolling/delta-neutral adjustments).
- One Repair block PER LEG you want to manage independently.
- `Position Detail` (strategy-level, returns Value/Quantity/Count) is how you stop a 2nd repair
  from firing after the 1st already reduced qty. Essential guard against double-exit.

## KEYWORD SCOPE TABLE (memorise this)
| Keyword | Scope | Allowed section | Returns |
|---|---|---|---|
| `PNL` | ENTIRE strategy, current counter | **Universal Exit only** | rupees |
| `PNL Underlying` | per-underlying | **Set Exit** | rupees |
| `Traded Instrument` | ONE leg by (Set,Cond,Leg) | condition builder / position builder | PRICE, QUANTITY, STRIKE, PNL, TIME |
| `Max Profit` (max_pnl) | strategy, per counter | Universal Exit | peak realised+unrealised — build custom TSL |
| `leg SL trail` / `leg TSL` | one leg | Universal Exit, Repair Once, Set Exit | Points OR **Percentage** mode |
| `Position Detail` | strategy-wide, all sets | any condition | Value / Quantity / Count |
| `Open positions` | per instrument | any | BOOLEAN (1/0) — NOT a quantity |
| `Net Delta` | all open positions of underlying | any condition | delta x qty |
| `Delta Neutral` | — | **Qty Fx ONLY** | qty needed to zero net delta |
| `Find Strike` | — | **Strike Fx** | strike by LTP/premium/**Delta**/greeks |
| `Get Strike` | — | Strike Fx | nearest strike to a value/math-op |
| `OHLC Sum` | 2 instruments | any | **combined premium** of a straddle |
| `Multiplier` | deployment | anywhere | scales SL/TP/qty with 1x/2x deploy |
| `Get Runtime` | — | anywhere | python/API variable (case+space sensitive) |

## PERCENTAGE SL/TP — the correct patterns
- **Leg-level % SL**: `Traded Instrument(...,PRICE)` of that leg x factor, compared to LTP.
  Short leg 50% SL => entry x **1.5**. Short leg 65% profit target => entry x **0.35**.
  Place in **Repair Once** (per leg). SELF-SCALING with IV — this is the fix for fixed-rupee stops.
- **Leg-level % trailing**: `leg TSL` with type=**Percentage**. 4 params:
  Activate at / Lock profit at / Increase profit by / Increase TSL by.
  *** GOTCHA: leg TSL does NOT work with re-entries. Legs must trade once only. ***
  => leg TSL and "Reactivate on exit after" are MUTUALLY EXCLUSIVE. Choose one.
- **Strategy-level trailing**: `Max Profit` in Universal Exit (works with re-entry).
- **Scale with deployment**: wrap SL/TP in `Multiplier` so 2x deploy doubles them automatically.

## DELTA — full support exists (CORRECTS my 2026-08-24 note)
- `Find Strike('NIFTY 50','CURRENT WEEK','Delta','Lesser Than',0.45)` — literal documented form.
  Filters: GREATER THAN / LESSER THAN / ANY (ANY = closest to value).
- Delta in **decimals**: 33% = 0.33. **PE must be NEGATIVE**: -0.33.
- Greeks computed off LTP of the option chain => illiquid strikes give wrong delta.
  Deep-OTM 0DTE wings are exactly where this breaks. Sanity-check selected strikes.
- `Net Delta(underlying)` for adjustment triggers; `Delta Neutral(...)` in Qty Fx auto-sizes the hedge.
  Futures have delta 1, so the keyword divides to give lot-multiples.

## BACKTEST ENGINE LIMITATIONS (critical — explains fantasy results)
Engine does NOT recognise: **India VIX**, all **OI** keywords, **Bid price / Ask price /
Bid-Ask Difference**, Sec, VWAP, VWAP Series, VWMA.
Engine does NOT consider: **advanced price execution settings**, **tranching**, **SLM orders**,
**rollovers**, overnight protection, corporate actions. Does not distinguish MIS/NRML/CNC.
Not supported: stock options, stock futures, MCX, CDS, NASDAQ.
=> **Slippage is structurally absent.** Backtest vs live WILL diverge.
=> Testing a "limit order" or "3 revision attempts" change in backtest is POINTLESS — engine ignores it.
   Execution improvements must be validated in forward/paper trading, never backtest.
- `Capital Required` explicitly "does not affect execution in any way" — it is a display assumption only.

## ADVANCED SETTINGS reference
- **Price execution 1**: Initiation Price (Market / Avg of Bid-Ask / Best Price / LTP), Revision attempts, Increase by (ticks).
- **Price execution 2**: Timeout, then Final action (Cancel / Execute at Market / Ignore).
- **Tranching**: Tranch size %, one tranch every N sec — splits big orders to cut impact.
- **Exit Shorts first = Yes** — correct for spreads; prevents a margin spike when the hedge leaves first.
- **Reactivate on exit after** — loops back to entry check after Universal Exit. Enables re-entry.
- **Trailing Stop Loss** (strategy level): Activate at / When profit increased by / Increase TSL by (RUPEES).
- **Check conditions every** — continuous vs 1/5 min. Continuous for 0DTE.
- **Take trades** — first trade after open, last before close.
- **Rollover on expiry** — auto-roll at set time (ignored by backtester).

## Strike selection methods available in Strike Fx
1. ATM +/- N **strike steps** (NOT points — SENSEX step=100, so '12' = 1200 pts).
2. By **option premium value** (find strike closest to a target LTP; can be half of ATM premium etc).
3. By **Delta** / greeks (see above).
4. By math-op on LTP via `Get Strike` (e.g. x1.05 = 5% away).
5. Relative to an indicator level (ORB high +100 pts etc).
Prefer (2) or (3) over (1) for regime-stable risk: fixed steps silently change your risk profile as IV moves.

## Risk-management layering (Tradetron's own 3-tier framing)
1. **Trade level** — `leg sl` / `leg tsl` per leg.
2. **Strategy level** — `PNL` / `Max Profit` in Universal Exit.
3. **Portfolio level** — deployment multiplier + capital allocation.
Use all three; most retail strategies only use tier 2 (Rishabh's does).
