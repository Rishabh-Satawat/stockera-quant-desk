>>> HUB WRITE: FAILURE_LOG.md  (append)

2026-08-27 | PLATFORM REGIME CHANGE — FastBT is now the only engine
Source: https://tradetron.tech/fastbt/  [V]
Since 25 Aug 2026 the previous engine is retired; ALL backtests run on
FastBT. Before cutover 306 real user jobs were replayed. Stated finding:
1 in 5 previous-engine runs had "quietly delivered nothing at all — no
fills, no report."
CONSEQUENCE: any Tradetron backtest reasoning predating 25 Aug 2026 is
suspect. All V6/B1/B2 lineage results are now doubly void.

2026-08-27 | CREDIT ECONOMICS CHANGED — scarcity assumption was wrong
OLD (our working model): 1 credit = 6 months of data tested.
NEW [V]: Rs.20 FLAT per backtest, ANY period, full 6+ year history.
Walk-forward out-of-sample validation is FREE, on single runs and sweeps.
Sweeps: 1 credit per variant. 6-variant = Rs.120. 16-variant max = Rs.320.
Failed/refused runs auto-refund.
CONSEQUENCE: "conserve the credit" framing is obsolete. We can afford
full-history runs and walk-forward on every test. This removes the main
argument against sweeps — but NOT the overfitting argument.

2026-08-27 | DETERMINISM RESOLVED — Branch A confirmed officially
Source: https://tradetron.tech/fastbt/  [V]
"Identical job -> identical fill book, byte for byte, across different
machines and repeated runs" — 5 of 5 runs. Engine builds are content-
fingerprinted.
CONSEQUENCE: Step 1b determinism probe is ANSWERED. True noise floor for
identical configs = ZERO. The Rs.8,633 "floor" is confirmed as a pure
contamination artifact. Parameter comparison is valid. Branch B is dead.

2026-08-27 | COST DEFAULTS CHANGED — and a cost-model bug was found
[V] Brokerage now defaults to ZERO (was non-zero); slippage defaults to
0.05% (was 1%).
Tradetron disclosed: engine and report were running TWO DIFFERENT cost
models. On one 25,948-fill job they disagreed by Rs.637,241. Now aligned
to 0.19%. On one job Sharpe fell from 4.43 to 0.48 once costs were
actually in the series.
CONSEQUENCE: the V7 report's cost figures are meaningless unless we know
what the sliders were set to at run time. Brokerage/order MUST be set to
Rs.20 explicitly. Zero-brokerage default produces flattering results.

2026-08-27 | CRITICAL: STOPS DO NOT USE BAR HIGH/LOW YET
Source: https://tradetron.tech/fastbt/ — labelled "built, not yet live"
Evaluating stops/targets against a bar's true HIGH and LOW is built but
DELIBERATELY NOT SWITCHED ON. Tradetron's stated reason: when one bar's
low hits your stop and its high hits your target, minute data cannot say
which came first.
CONSEQUENCE FOR IF V7 — SEVERE: the 250-pt breach row, the -2200 stop and
the +2600 target are currently evaluated on a single price per candle
(Close), NOT intraday extremes. Live deployment WILL trigger these more
often and at worse prices than backtest shows. Every V7 threshold result
is optimistically biased by an unquantified amount. This is a systematic
bias, not noise, and it cannot be corrected by the cost lab.

2026-08-27 | 34% of real volume still not honestly backtestable
[V] Measured across 323 live strategies / 111,009 real fills: share of
real trading volume Tradetron "cannot honestly backtest" fell from 44%
to 34%. FastBT declines rather than silently mis-booking.
CONSEQUENCE: confirm our keyword set is inside the supported 66%.

2026-08-27 | TRADETRON SHIPS AN MCP SERVER
[V] https://tradetron.tech/tt-assistant/ and /build-with-claude/
Connect an MCP-capable AI to the Tradetron account; describe a strategy
in plain English; get a real EDITABLE TEMPLATE in the Strategy Builder
plus the full backtest report URL returned in chat.
CONSEQUENCE: this is a higher-priority connector than Zerodha Kite for
our purpose. It closes the build->backtest->diagnose loop without manual
UI work, and it eliminates the transcription errors that have cost us
two build attempts. ACTION: connect this.
