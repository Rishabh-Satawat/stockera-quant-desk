=========================================================
TASK 6 — POSITIONS, EXITS AND REPAIR LOGIC
Deliverables: 06_POSITIONS.md · 07_RISK_EXITS.md
Prerequisite: Tasks 1-5 complete.
Inherits all rules from Task 1.
=========================================================

OBJECTIVE
Everything about holding, adjusting and closing a position.
This is where the operator has already been bitten twice —
an exit block set to AND that made rows unreachable, and a
repair strike-lock issue — so the standard here is higher
than elsewhere. Entry logic errors cost an opportunity.
Exit logic errors cost capital.

---------------------------------------------------------
6.1 THE POSITION STATE SURFACE
---------------------------------------------------------
Document completely, from tt_lookup_keyword plus the
keyword documentation plus QnA threads 883 and 884:

 - Position Detail. Documentation describes it as one of
   the most important and versatile keywords, returning
   five values for the traded instrument including PRICE.
   Enumerate ALL FIVE, in order, exactly. State for each
   whether it reflects trigger or fill — this feeds back
   into Task 4.1 and may resolve it.
 - Traded Instrument, Traded Instrument Name, Net Quantity.
   QnA 883 documents referencing a specific Repair Once
   condition's strike through Traded Instrument. Capture
   the exact addressing scheme: how do you point at leg 2
   of set 1, or at the strike taken by the second Repair
   Once? Argument order is where this breaks silently.
 - How to count open positions, and how to restrict entries
   by that count (QnA 884's stated purpose).
 - How to read per-leg versus net position state.
 - What every one of these returns when the position does
   NOT exist. Expected: None or empty, silently, leaving
   the containing condition permanently true or false. Test
   the claim, state it for each keyword individually.

---------------------------------------------------------
6.2 REPAIR SEMANTICS
---------------------------------------------------------
Sources: tradetron.tech/blog/repair-once-and-repair-
continuous, help.tradetron.tech articles on both, QnA 1296,
and the FAQ.

Establish, each tagged:
 - Repair Once: satisfied once, never checked again. Once
   per WHAT — per counter, per entry, per deployment? This
   is the single most consequential ambiguity in repair
   logic. Settle it.
 - Repair Continuous: checked perpetually. What stops it?
   Is there any built-in limiter, or must the operator
   build one from Position Detail counts?
 - The blog states the Repair block partially modifies an
   existing entered position, and that each leg (call/put)
   has an INDEPENDENT Repair block. Confirm, and document
   what that means for a four-leg iron fly — four
   independent repair blocks, or two?
 - Can a Repair fire before the entry it repairs has
   filled? Task 1 Q4 says find_traded_instrument returns
   None in that situation. Generalise: what is the full
   list of things unavailable at repair time?
 - THE STRIKE-LOCK ISSUE. The operator has a recorded
   problem here. Document precisely: when a Repair adds or
   modifies a leg, is the strike resolved fresh at repair
   time or locked from entry? What does Find Strike return
   at repair time, given it is anchored to the DAY'S
   OPENING ATM (Task 1 Q3)? For a multi-day positional
   trade, a repair on day 3 anchored to day 3's opening ATM
   is a different strike universe than the entry used.
   State the consequence explicitly.

---------------------------------------------------------
6.3 THE EXIT ARCHITECTURE — HIGHEST SCRUTINY
---------------------------------------------------------
 - Set Exit versus Universal Exit: scope, precedence, what
   each closes, and what happens to runtime variables in
   each case (cross-reference Task 4.2).
 - THE AND/OR FATAL BUG. An exit block set to AND makes
   mutually exclusive rows PERMANENTLY UNREACHABLE — the
   operator hit this live. Document: the exact UI label of
   the toggle, its default, where it appears, and how to
   verify the current setting on an existing strategy in
   under ten seconds. Then write a standing pre-flight
   check: for every exit block, list its rows and confirm
   no two are mutually exclusive under AND.
 - Row ordering: does it matter? If two exit rows are true
   in the same evaluation, which wins?
 - Exit at market versus limit, and what happens when a
   limit exit does not fill.
 - Square-off timing, and interaction with the advanced
   settings that govern session start and reactivate time.
 - Per-leg exit versus whole-set exit: how do you close ONE
   leg of four without closing the set? Task 2.4 records
   that a sell leg in a DIFFERENT set opens a new short
   rather than closing anything. Give the correct
   construction.

---------------------------------------------------------
6.4 THE PRE-FLIGHT CHECKLIST — THE PRODUCT OF THIS TASK
---------------------------------------------------------
Write a numbered checklist to run against EVERY strategy
before deployment. Each item must be answerable in seconds
by looking at one place. At minimum:
 - every exit block's AND/OR setting confirmed correct
 - no two rows in an AND block mutually exclusive
 - every runtime variable read has a corresponding write
 - every runtime variable has a reset, or a documented
   reason it does not need one
 - no runtime variable named after a reserved keyword
   (Task 1 Q9)
 - every leg has an exit path that can actually fire
 - repair blocks cannot fire before their entry fills
 - strike resolution method consistent between entry and
   repair
 - fixed-rupee thresholds reviewed against the deployment
   multiplier
 - tt_check_backtestability run and declines reviewed

This checklist is the deliverable the operator will use
most often. Write it to be used, not to be admired: no
prose, one line per check, each with what "pass" looks
like.

---------------------------------------------------------
6.5 AUDIT V7 AGAINST THE CHECKLIST
---------------------------------------------------------
Run the checklist against the operator's live strategy and
report every finding, including passes. Anything that fails
goes into 13_FAILURE_LOG.md with the date and the proposed
fix. Do not apply fixes to the live deployment.

---------------------------------------------------------
STOP AND REPORT
---------------------------------------------------------
a) files written
b) all five Position Detail return values, in order, with
   trigger-or-fill stated for PRICE
c) Repair Once "once per what" — settled, one sentence
d) the strike-lock verdict and its consequence for
   multi-day positions
e) the completed pre-flight checklist
f) V7 audit results, pass and fail both
g) anything contradicting operator material, flagged
h) screenshot checklist for remaining [U] items
i) SELF-REVIEW section

Some additional detail i got from genspark :
Three things I'd flag before you paste these.

Task 4's most likely surprise is that Position Detail's PRICE turns out to be the fill price, which would make the whole trigger-vs-fill problem solvable with a keyword you already have. I've wired that check into both Task 4 and Task 6 so whichever runs first catches it.

Task 5 has one budget trap worth watching: if brokerage is charged per leg rather than per order, an eight-leg round trip on a four-leg fly is ₹160 per cycle, not ₹40, and over 33 samples that's most of your recorded loss. Worth knowing before you read the P&L.

Task 6's strike-lock section is the one I'm least confident is well-specified, because your recorded issue is summarised in your task table as "repair strike-lock" without detail. If you can tell me what actually went wrong there, I'll tighten that section — right now the prompt is asking the agent to characterise a problem it has to reconstruct from scratch.

What should we do next, and what did I learn that changes the plan? Next: run Task 4's reset audit even if you don't run the rest — an unreset runtime variable in a live strategy is the cheapest serious bug on this list to find and fix. What I learned is that Tradetron's state model is counter-keyed rather than day-keyed and persists until Universal Exit, which means "it worked in testing" and "it works on the second trade" are genuinely different claims, and nothing in your existing material distinguishes them.
