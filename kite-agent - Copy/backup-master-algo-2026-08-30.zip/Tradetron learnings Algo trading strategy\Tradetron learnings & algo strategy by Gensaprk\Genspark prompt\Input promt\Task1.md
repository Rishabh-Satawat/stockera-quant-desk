=========================================================
TASK 1 — TRADETRON KEYWORD GROUND TRUTH
Deliverables: 00_INDEX.md · 02_KEYWORDS.md · 03_INSTRUMENTS.md
              12_KEYWORD_LEDGER.md
Operate under ALGO_DESK_CHARTER_v1.md + the Tradetron Master Spec
prompt. This brief OVERRIDES both where they conflict.
=========================================================

ROLE
You are a senior algorithmic-trading systems documentarian with
operational expertise in Tradetron and Indian F&O microstructure
(NSE + BSE). You write for one reader: a downstream AI agent that
will use your output as its ONLY source of truth when building
Tradetron strategies. That reader cannot see the UI. It knows
nothing you do not write down. Every ambiguity you leave becomes a
silent failure in a live system with real capital at risk.

OBJECTIVE
A complete, verification-tagged inventory of the Tradetron
condition-builder and position-builder keyword surface, such that
an agent with zero prior platform knowledge can construct any
condition row without guessing a label, an argument order, or a
rendered string.

WHY THIS FIRST
On 2026-08-27 a fabricated keyword ("Get Var") reached the operator
and cost a build attempt. The keyword surface is not written down
anywhere checkable. Until it is, every build carries that risk.

---------------------------------------------------------
TAGGING — an untagged claim is a defect
---------------------------------------------------------
[V] Verified   official Tradetron source. FULL URL inline, plus the
               page's publication or "updated on" date.
[O] Observed   from a supplied backtest report or builder
               screenshot. Cite which.
[I] Inferred   reasoning shown in one explicit sentence.
[U] Unverified plausible, unconfirmed. MUST appear in OPEN ITEMS.

STALENESS RULE: any claim about the BACKTEST ENGINE sourced before
25 Aug 2026 is automatically [U] — the engine was replaced that
date. Any claim about lot sizes, expiry weekdays, session timings,
margins or charges sourced before 2025 is automatically [U] pending
re-verification against an NSE/BSE/SEBI circular.

NEVER INVENT a keyword name, parameter, dropdown label, menu path
or rendered string. If you cannot confirm the exact spelling as it
appears in the UI, write:
    [U] EXACT UI LABEL UNCONFIRMED — verify in builder
and move on. A wrong keyword name is worse than a gap, because the
reader will trust it.

EXACT STRINGS ONLY. Give the VERBATIM rendered output including
every space, quote and comma. Trailing-comma and empty-field
variants are functionally significant. Never normalise silently.

---------------------------------------------------------
METHOD — EXHAUSTIVE, NOT SAMPLED
---------------------------------------------------------
1. Crawl tradetron.tech/keyword/documentation IN FULL. It is long
   and lazy-loads; if one fetch truncates, fetch by byte offset
   until you reach the end. REPORT the total keyword count found
   and your coverage percentage. A partial crawl silently produces
   a partial bible — state coverage explicitly.
2. Expand EVERY sub-keyword and nested option. Many keywords are
   legal only inside others (Instrument Name inside LTP; Find
   Strike only in Strike Fx). Record nesting rules explicitly.
3. Cross-reference help.tradetron.tech/en/category/
   keywordsstrategy-logics-1miek11/ article by article.
4. Cross-reference qna.tradetron.tech threads 883, 884, 890, 1254,
   2362 and anything they link. Mark each answer STAFF or
   COMMUNITY and record its date.
5. Pull official Tradetron YouTube transcripts for keyword and
   strike-selection videos. Transcript-derived UI claims are [U]
   until screenshot-confirmed — speech does not capture screen
   state ("select this dropdown" transcribes as "this").
6. Unresolved after all five => [U] + OPEN ITEMS + the EXACT
   evidence that would settle it.

---------------------------------------------------------
02_KEYWORDS.md — grouping
---------------------------------------------------------
time & date · price/LTP · PNL & max-profit · position state ·
math & logic (Absolute, Round, Math Operation, and max nesting
depth) · greeks · OI & volume · runtime & variables · expiry ·
strike selection

Use the mandatory block format. PLUS, for every keyword:
 - LEGAL CONTEXTS: Entry / Repair Once / Repair Continuous /
   Universal Exit / Set Exit / Strike Fx / Qty Fx / Expiry Fx /
   Initialise Variables. A keyword legal in one and not another is
   a top-tier failure mode.
 - NESTING: what may nest inside it; what it may nest inside.
 - MULTIPLIER BEHAVIOUR: does its value scale with the deployment
   multiplier? Fixed-rupee thresholds do NOT. Flag every scaling
   trap. This has already bitten the operator on a live strategy.
 - LOT-SIZE SENSITIVITY: does its meaning change when the
   exchange lot size changes? FastBT applies HISTORICAL lot size
   per trade date from circulars (NIFTY went 75-50-25-75-65), so a
   fixed-rupee threshold means a different move in different years.
 - BACKTEST SUPPORT: YES / NO / PARTIAL under FastBT specifically.
   Maintain a consolidated list of keywords that are silent no-ops
   or trigger a refusal. Note: FastBT declines constructs it cannot
   faithfully simulate rather than mis-booking them; ~34% of real
   traded volume is still not honestly backtestable. Determine
   whether our keyword set sits inside the supported 66%.

---------------------------------------------------------
03_INSTRUMENTS.md — must resolve
---------------------------------------------------------
 - Every segment token and when each applies: NSE, NSE_IDX, NFO,
   BSE, BSE_IDX, BFO, MCX, CDS. State and justify the hard rule:
   index/spot reads use _IDX; contracts use the derivatives
   segment. Show what a wrong segment does (null, silent
   non-firing — NOT an error).
 - THE TRAILING-COMMA QUESTION. Is the correct SENSEX spot string
   'BSE_IDX,SENSEX,,,,,'  or  'BSE_IDX,SENSEX,,,,0,0' ?
   Both appear in operator material. Determine what the builder
   actually emits. Document the difference. DO NOT normalise.
 - ATM vs ATM-SPOT vs ATM-FUT per context. Document the confirmed
   defect: Instrument Name resolves ATM off FUTURES; only Strike
   Fx resolves off SPOT. Staff-confirmed, QnA 2362, live example
   (Nifty spot 18,161 / futures 18,228 -> wrong strike). Observed
   SENSEX basis 2026-08-27: spot 76,933.59 vs fut 76,893.45 =
   -40.14 pts.
 - Strike grid intervals for NIFTY, BANKNIFTY, FINNIFTY, SENSEX,
   BANKEX — verified against an EXCHANGE circular with its date.
   Then the offset-to-POINTS mapping. LOAD-BEARING: the operator's
   entire structure assumes SENSEX interval = 100, so offset 7 =
   700 points. Confirm or refute with a citation.
 - Current lot sizes with circular citations. SENSEX = 20 per BSE
   contract spec (asset code BSX), raised from 10; BANKEX 15 -> 30.
 - Expiry weekday regime. SEBI May-2025: all equity derivatives
   expire Tuesday or Thursday, effective 01 Sep 2025. NSE = Tuesday
   [confirm]. BSE SENSEX = Thursday [CONFIRM against BSE circular —
   currently [U], inferred only from an observed 27-Aug-2026
   Thursday expiry]. State whether FastBT handles the BSE per-date
   migration, since any backtest spanning Sep-2025 contains a mixed
   regime.
 - Set No / Condition No / Leg No: definitions, how to identify
   them in the UI, and how leg BUILD ORDER determines leg numbering.

---------------------------------------------------------
PRE-SEEDED QUIRKS — confirm or refute, do not rediscover
---------------------------------------------------------
Q1 "Get Var" is NOT a valid option-price reader. Correct form is
   LTP( Instrument Name(...) ). Confirm the exact rendered string.
Q2 Instrument Name ATM = futures basis (QnA 2362). Determine
   whether ATM-SPOT is selectable inside Instrument Name AT ALL.
   A three-year-old unanswered forum question; settle it.
Q3 Find Strike holds only +/-50 strikes around the DAY'S OPENING
   ATM and returns None silently outside. Confirm the range and
   the opening-ATM anchoring. Document delta mode fully: decimal
   values, PE must be NEGATIVE, illiquid-strike Greek warning.
   Source: help.tradetron.tech/.../how-to-use-find-strike-with-
   delta-12mg2d7/
Q4 find_traded_instrument cannot be referenced by a leg firing on
   the SAME entry condition (the referenced leg has not filled at
   resolution time; returns None). Legal only from Repair Once or
   a later entry. Confirm.
Q5 Runtime Variable / Get Runtime (help.tradetron.tech, updated
   27-05-2026). Capture at TRIGGER or at FILL? Persistence across
   run_counter? Manual reset required? Available in Entry, Repair
   AND Set Exit? This determines whether credit-relative exit
   thresholds are buildable at all — currently the highest-value
   open question on the desk.
Q6 Top-level AND/OR toggle: exact UI label, and confirm that an
   exit block set to AND makes mutually exclusive rows permanently
   unreachable. This was a live fatal bug in the operator's build.
Q7 India VIX as a condition input: exact instrument string and
   which contexts accept it. FastBT lists India VIX as native
   regime data.
Q8 Sweep parameter discovery: only LITERAL numbers inside the
   strategy are sweepable; 0, 1 and -1 are skipped as flags;
   runtime-computed or variable-held values are invisible.
   Confirm, and state what this means for credit-relative
   thresholds (a threshold expressed as a Math Operation may
   become un-sweepable).

---------------------------------------------------------
12_KEYWORD_LEDGER.md
---------------------------------------------------------
One row per keyword:
 name | args in order | legal contexts | rendered string | tag |
 source URL | source date | multiplier-scales? | lot-size-
 sensitive? | FastBT support | quirks | last verified
This is the machine-checkable index. Every future build diffs
against it. Append-only.

---------------------------------------------------------
STOP AND REPORT — do not proceed to Task 2
---------------------------------------------------------
a) files written, with paths
b) keywords documented / total found (coverage %)
c) [V]/[O]/[I]/[U] counts per file
d) verdict on each of Q1-Q8
e) TOP 15 [U] ITEMS AS A NUMBERED SCREENSHOT CHECKLIST. For each:
   the exact panel, which dropdown to open, and what must be
   visible in frame. The operator has the UI; you do not. This is
   the single most valuable output of this task.
f) any YouTube video where the transcript was insufficient: URL
   plus the specific timestamps to screenshot.
g) ANYTHING THAT CONTRADICTS EXISTING OPERATOR MATERIAL, flagged
   loudly. Contradictions are higher-value than confirmations.

STANDING QUESTION
Close with: "What should we do next, and why that before anything
else?" One primary action, its cost, its binary pass/fail gate,
and what it unblocks.

FYI we have more task linned up approx. 10 ahead. 