>>> HUB WRITE: MARKET_JOURNAL.md  (append)

2026-08-27 | MARKET STRUCTURE IN FORCE — verify before any spec claim

CLOSING AUCTION SESSION (CAS) — LIVE NOW
Source: nseindia.com/static/products-services/closing-auction-session
        updated 12/08/2026  [V]
Phase 1 applies ONLY to cash-segment stocks that have derivatives.
Not index options. Timings: CTS ends 15:15 for CAS securities; CAS
15:15-15:35 (reference price = VWAP 15:00-15:15; band +/-3%); matching
15:30-15:35; transition to 15:50; post-close 15:50-16:00.
EQUITY DERIVATIVES SEGMENT SESSION IS NOW 09:15-15:40.
Non-CAS securities continuous session unchanged 09:15-15:30.
Only limit and market orders in CAS. Stop-loss and iceberg orders are
NOT allowed and are NOT carried forward from CTS.
IMPACT ON IF V7: 14:45 exit sits well clear. No direct impact. But the
derivatives close moved to 15:40 — any strategy with a >=15:10 or
>=15:15 exit row needs re-checking.

EXPIRY DAY REGIME
SEBI May-2025 circular: all equity derivative contracts must expire on
a TUESDAY or THURSDAY. Effective 01 Sep 2025. [V]
NSE (NIFTY, BANKNIFTY, FINNIFTY): Tuesday. [V - NSE contract specs]
BSE (SENSEX, BANKEX): Thursday. [U - infer from 27 Aug 2026 = Thursday
expiry observed in operator screenshots; CONFIRM against BSE circular]
IMPACT: any backtest spanning the Sep-2025 transition contains a mixed
expiry-weekday regime. FastBT states it handles per-date expiry
migrations (Thu->Wed->Tue). Verify this for BSE specifically.

SENSEX CONTRACT
LOT SIZE 20. Source: bseindia.com contract specification, asset code
BSX. [V] (raised from 10 to 20; BANKEX 15 to 30)
Strike interval: 100 points. [U - CONFIRM against BSE circular]
=> wing offset +/-7 strikes = +/-700 points ONLY IF interval is 100.
This is load-bearing for the entire IF V7/V8 structure.

OBSERVED 27 AUG 2026 (expiry day, operator screenshots)
SENSEX spot 76,933.59 (-0.70%) | futures 76,893.45 | basis -40.14
INDIA VIX 11.1 (+0.5) | PCR 0.5
Open 09:15 77,472.94 -> 19:30 76,933.60 = -539.34 pts = 1.00 sigma
Next expiry 03 Sep 2026.
OI note: combined-expiry Call OI chg +3.03 Cr vs Put +89.86 L looks
violently bearish, but 03-Sep-only was +12.36 L vs +9.98 L (ratio 1.24).
The 3 Cr is the EXPIRING series settling to zero — mechanical, not
positioning. Expiry-day PCR and OI on the dying series carry no
directional information. Read positioning from the NEXT series only.
Sensibull states exchange OI is 3-minute delayed; never a live signal.
