# Tradetron MCP and FastBT Knowledge Capture Plan

## Goal
Review the four user-provided Tradetron URLs in My Browser and through read-only public retrieval, inspect the full rendered text, scroll through each page, follow relevant public clickable links and controls, capture resulting page states and text, analyze the products and workflows described, and deliver detailed Markdown knowledge files suitable for loading into an AI memory system.

## Scope and source handling

The primary sources are:

1. `https://tradetron.tech/mcp-tools/`
2. `https://tradetron.tech/mcp-tools/tt-mcp-instructions.md`
3. `https://tradetron.tech/fastbt`
4. `https://tradetron.tech/tt-assistant/`
5. `https://tradetron.tech/fastbt/` (the trailing-slash duplicate will be checked and canonicalized if identical)

The user describes four links, while five URL strings are supplied because `/fastbt` and `/fastbt/` may be the same resource. The review will treat them as one logical FastBT page unless their content differs. The main analysis will prioritize observed page content, public links, and rendered behavior. Limited external research will be used only to clarify terminology or relationships that the pages themselves leave ambiguous.

## Phases

### Phase 1 — Establish page inventory and canonical URLs

Open each supplied URL, record redirects, page titles, canonical URLs, and whether the page is HTML, Markdown, documentation, a product landing page, or a duplicate. Save the initial source map before deeper browsing.

### Phase 2 — Read and capture each page completely

For each canonical page, inspect the complete available text, scroll through the page in sections, and record headings, paragraphs, code blocks, tables, images, warnings, examples, navigation, and footer links. Use direct extraction for text-only pages and browser rendering for visual or interactive content. Preserve exact URLs for important references.

### Phase 3 — Inspect public clickable controls and destinations

Identify meaningful clickable controls, including navigation links, documentation links, GitHub/repository links, product buttons, demo buttons, download links, login or signup links, and expandable sections. Follow public informational destinations one at a time. Do not log in, submit forms, purchase, install, authorize integrations, or trigger irreversible actions. If a control requires authentication or a sensitive action, record that requirement instead of proceeding. Capture the destination text and explain how it relates to the source page.

### Phase 4 — Analyze the technical and product concepts

Synthesize what Tradetron is communicating about MCP tools, the Tradetron MCP server/instructions, FastBT, TT Assistant, strategy automation, APIs, data flow, setup requirements, supported workflows, limitations, and relationships between the products. Separate direct observations from interpretation. Note terminology, prerequisites, example prompts or commands, configuration steps, and any security or operational considerations.

### Phase 5 — Produce AI-memory Markdown deliverables

Create either two or four Markdown files, choosing the grouping that best preserves retrieval clarity. The likely default is:

- `tradetron_mcp_tools_knowledge.md`: MCP Tools page plus the `tt-mcp-instructions.md` documentation.
- `tradetron_fastbt_tt_assistant_knowledge.md`: FastBT and TT Assistant pages, including the trailing-slash comparison.

If the content is sufficiently distinct, also produce per-page files. Each file will include source URLs, canonicalization notes, an executive summary, page-by-page factual notes, clickable-link findings, setup/workflow explanations, terminology, limitations, and concise memory-oriented facts.

### Phase 6 — Quality assurance and delivery

Check that every supplied URL is covered, duplicate URLs are identified, every important public clickable destination is recorded, no sensitive action was taken, factual claims have source URLs, code/configuration examples are preserved accurately, and the Markdown is readable by both humans and retrieval systems. Deliver the Markdown attachments and, if useful, a compact source index or raw capture notes file.

## Deliverables

At minimum, deliver two detailed Markdown files grouped by MCP and FastBT/TT Assistant. Include a source index, canonical URLs, page relationships, observed clickable destinations, and an explicit distinction between documented behavior and analyst interpretation. Do not convert the Markdown to PDF unless the user later requests it.

## Assumptions and open risks

The pages may expose third-party links, login walls, dynamic controls, or buttons that do not produce public content. Such controls will be logged with their visible label and access requirement rather than bypassed. Browser rendering may show content that a text extractor misses; rendered browser observations take precedence for interactive behavior. “Every clickable button” is interpreted as every meaningful public informational control, not every social icon, cookie control, ad, or destructive/account action. The supplied duplicate FastBT URLs will be compared before reporting the final count of logical pages.

## Test and verification plan

Verify URL coverage against the source inventory; compare extracted and rendered text for each page; confirm important links resolve to the recorded destinations; check Markdown headings and tables; search outputs for missing source references, truncated sections, malformed links, and accidental credentials; and ensure no login, submission, purchase, or integration authorization was performed.
