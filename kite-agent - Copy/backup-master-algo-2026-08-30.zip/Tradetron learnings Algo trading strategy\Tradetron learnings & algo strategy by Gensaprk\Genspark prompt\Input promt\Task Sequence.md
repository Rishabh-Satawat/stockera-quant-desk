Revised task sequence
#	Task	Deliverables	Cost	Gate
1	Keyword ground truth	00_INDEX, 02_KEYWORDS, 03_INSTRUMENTS, 12_KEYWORD_LEDGER	free	Coverage %, Q1–Q8 verdicts, numbered screenshot checklist
2	Failure taxonomy, seeded from 13_FAILURE_LOG	13_FAILURE_LOG, 04_CONDITION_LOGIC, 05_RUNTIME_VARS	free	Runtime Variable capture-at-trigger-vs-fill resolved
3	Connect Tradetron MCP + FastBT re-baseline	19_TRADETRON_MCP, 09_BACKTESTING	₹20	V7 re-run on FastBT with brokerage=₹20, slippage set explicitly, walk-forward on
4	Positions & exits	06_POSITIONS, 07_RISK_EXITS	free	Repair strike-lock + Position Detail guard documented
5	Execution & platform	08_EXECUTION, 01_PLATFORM_MAP	free	Bias inventory complete
6	Validation discipline	17_VALIDATION_DISCIPLINE	free	Minimum sample sizes fixed per metric
7	Options craft	16_OPTIONS_CRAFT	free	—
8	Playbooks & template	10_PLAYBOOKS, 11_SPEC_TEMPLATE	free	V8 buildable from spec alone
9	Strategy selection	18_STRATEGY_SELECTION	free	—
10	Data layer (Dhan/Kite)	20_DATA_LAYER	build	Slippage model from real bid/ask