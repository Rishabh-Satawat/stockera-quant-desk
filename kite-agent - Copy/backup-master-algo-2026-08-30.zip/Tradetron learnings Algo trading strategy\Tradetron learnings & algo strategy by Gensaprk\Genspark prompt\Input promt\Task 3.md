=========================================================
TASK 3 — INSTRUMENTS, STRIKES, EXPIRIES + QUIRK CLOSURE
Deliverables: 03_INSTRUMENTS.md · 13_FAILURE_LOG.md (append)
Prerequisite: Tasks 1-2 complete.
Inherits all evidence-tagging, self-review, hub-write and
closing rules from Task 1.
=========================================================

OBJECTIVE
The MCP knows keywords. It does not know exchange
circulars. This task resolves everything about WHICH
instrument a string actually points at — the layer where
a wrong answer produces a silently wrong trade rather than
an error.

SPECIAL SOURCING RULE FOR THIS TASK
Lot sizes, strike intervals, expiry weekdays and session
timings must be cited to an NSE, BSE or SEBI circular WITH
ITS DATE, or to tt_check_underlying_support /
tt_list_underlyings / tt_market_calendar. A forum post is
not acceptable for these. A number without a dated citation
is [U], full stop, no matter how confident you are.

---------------------------------------------------------
3.1 SEGMENT TOKENS
---------------------------------------------------------
Every segment token and exactly when each applies: NSE,
NSE_IDX, NFO, BSE, BSE_IDX, BFO, MCX, CDS, and any others
the platform exposes (crypto and US segments now exist).

State and justify the hard rule: index/spot reads use the
_IDX form; contracts use the derivatives segment.

CONFLICT TO RESOLVE: the keyword documentation's Instrument
Name section lists exchanges as NSE, NFO, MCX, CDS, BITBNS,
FX and NASDAQ-eq — it does NOT list BSE_IDX or BFO, yet
FastBT backtests SENSEX and BANKEX and the operator trades
SENSEX weeklies live. Determine whether that page is stale
or whether BSE instruments are reached another way. Use
tt_check_underlying_support to settle it. This matters
directly: the operator's live strategy is SENSEX.

Then show what a WRONG segment does. Expected: null, silent
non-firing, NOT an error. Confirm.

---------------------------------------------------------
3.2 THE TRAILING-COMMA QUESTION
---------------------------------------------------------
Which is correct for SENSEX spot:
   'BSE_IDX,SENSEX,,,,,'   or   'BSE_IDX,SENSEX,,,,0,0' ?
Both appear in operator material. Determine what the
BUILDER ACTUALLY EMITS — the exported strategy from Task 2
is the decisive evidence, because it is what the engine
consumes. Document the difference and what each does.
DO NOT NORMALISE. Report both if both are legal.

---------------------------------------------------------
3.3 ATM RESOLUTION — CLOSE Q2 DEFINITIVELY
---------------------------------------------------------
Operator's recorded belief: Instrument Name resolves ATM
off FUTURES; only Strike Fx resolves off SPOT. Source is
QnA 2362, staff-confirmed, with a live example — Nifty spot
18,161 vs futures 18,228 producing a wrong strike.

Contradicting evidence: the keyword documentation carries
"ATM SPOT" as a separate keyword and states it can be used
INSIDE Instrument Name to fetch a spot-based ATM
instrument. The plain "ATM" keyword is documented as
futures-based.

Resolve it. Both keywords, both contexts, four cells:
       ATM in Strike Fx | ATM in Instrument Name
  ATM SPOT in Strike Fx | ATM SPOT in Instrument Name
Fill every cell with what it resolves off, tagged.

If the operator's belief is refuted, say so in the first
line of the section and state what he should change. His
SENSEX structure may carry an unnecessary workaround.

Record the observed basis for scale: SENSEX 2026-08-27,
spot 76,933.59 vs futures 76,893.45 = -40.14 points. On a
100-point grid that is under half a strike — so quantify
how often the two methods actually diverge before
recommending a rebuild.

---------------------------------------------------------
3.4 STRIKE GRIDS AND LOT SIZES
---------------------------------------------------------
Strike interval for NIFTY, BANKNIFTY, FINNIFTY, SENSEX,
BANKEX — each cited to an exchange circular with its date.
Then the offset-to-POINTS mapping for each.

LOAD-BEARING: the operator's entire structure assumes
SENSEX interval = 100, so offset 7 = 700 points. Confirm or
refute with a citation. If refuted, that is the headline of
this task.

Current lot sizes with circular citations. Operator's
record: SENSEX = 20 (BSE contract spec, asset code BSX,
raised from 10); BANKEX 15 → 30. Verify both.

Historical lot-size series where obtainable — FastBT
applies the lot size in force ON EACH TRADE DATE, so any
multi-year backtest silently changes position size as the
lot changes. NIFTY went 75-50-25-75-65. Document the
consequence for fixed-rupee thresholds.

---------------------------------------------------------
3.5 EXPIRY REGIME
---------------------------------------------------------
SEBI's May-2025 direction: equity derivatives expire
Tuesday or Thursday, effective 01-Sep-2025.
 - NSE weekday: confirm against an NSE circular.
 - BSE SENSEX weekday: currently [U] in our material,
   inferred only from an observed Thursday expiry on
   2026-08-27. CONFIRM against a BSE circular.
Do not carry either forward untagged.

FastBT states it handles the real expiry-day migrations
(Thu→Wed→Tue) per-date. Confirm, and state explicitly:
any backtest spanning Sep-2025 contains a MIXED regime.
What does that do to a weekly strategy's sample?

Cross-check every expiry claim against tt_market_calendar
where the tool allows a date query.

---------------------------------------------------------
3.6 FIND STRIKE EXPIRY MATRIX — OPERATIONAL CONSTRAINT
---------------------------------------------------------
Documentation states Find Strike works with:
  NIFTY 50   — current week, next week, current month,
               next month
  NIFTY BANK — current month, next month ONLY
  FINNIFTY   — current month, next month ONLY
  SENSEX     — current week, current month
  Equity options — unreliable, advised against
  MCX and MIDCP — not compatible
Confirm this matrix. Then state plainly which structures
the operator might want to build that this FORBIDS. A
premium-selected or delta-selected BANKNIFTY WEEKLY strike
appears impossible via Find Strike — verify, and if true,
give the workaround or declare the structure unbuildable.

---------------------------------------------------------
3.7 SET / CONDITION / LEG NUMBERING
---------------------------------------------------------
Definitions, how to identify each in the UI, how build
order determines leg numbering, and how they are referenced
from keywords such as Delta or Traded Instrument. Confirm
against the Task 2 export, which shows the real encoding.

---------------------------------------------------------
STOP AND REPORT
---------------------------------------------------------
a) files written
b) a citation table: every number in 03_INSTRUMENTS.md with
   its source and source date. Any uncited number is a
   defect — list defects separately.
c) Q2 verdict, stated in one sentence at the top
d) SENSEX strike interval verdict — confirmed or refuted
e) BSE expiry weekday verdict — with the circular
f) anything that contradicts operator material, flagged
g) screenshot checklist for whatever remains [U]
h) SELF-REVIEW section

REMINDER: Tradetron app renewal expires 08-SEP-2026. If it
has not been confirmed renewed, say so at the top of your
reply before anything else.

some additional information given by gensaprk :
What the sources say before you spend anything
Runtime variables capture at TRIGGER, not fill. "The moment your entry fires, the variable is created and the value is locked in." Available in Entry, Repairs and Set Exits. So credit-relative exit thresholds are buildable — but on triggered prices, not filled prices. On a four-leg SENSEX iron fly that gap is your entire slippage budget, and it's systematically in the wrong direction because the value you compare against is better than the price you got. [V — help.tradetron.tech, updated 27/05/2026]

Persistence is worse than "resets per counter." Variables live at strategy level and persist across the cycle until a Universal Exit — unless you reset them manually by re-creating the same variable with value zero after your exit. Meaning: a strategy without explicit resets carries stale entry-credit values into the next trade, and the exit condition then evaluates against a number from a trade that closed days ago. Silently. This is the highest-probability live bug in your book right now. [V]

Init Var is not "runs once per deployment." It's once per run counter, written when the bot is assigned — not on trade execution, not daily. If the strategy stays Active without trading, the counter doesn't change and Init Vars are never rewritten the next morning. And they may not appear in Runtime Data at all until a trade executes in that counter, which looks identical to "my variable didn't write." [V]

That last one means your Task 4 gate — "capture-at-trigger-vs-fill resolved" — is already met from documentation. So Task 4 shouldn't spend its budget re-deriving it. It should spend it on the reset audit, which is the thing that's actually costing you money.

Three prompts below. Task 4 is retargeted accordingly; 5 and 6 as sequenced.

NOTE : YOU have to cross check every thing mentioned if you can. From the official source of tradetron only! 
