# Tradetron review capture notes

## MCP tools page: first rendered capture

Source: https://tradetron.tech/mcp-tools/

The page presents the Tradetron MCP as a connector for ChatGPT, Gemini, Grok, and Claude that turns plain-English requests into actions on a user’s Tradetron account. It claims 47 tools, 8,500+ resolvable underlyings, operation on the user’s own AI plan, and zero lines of code.

The workflow is staged as Explore, Build, and Run. Explore handles grounded product questions such as plans, broker support, tradability, and market hours without an account. Build resolves keywords, validates a strategy specification, and creates a real template. Run is aimed at live-book operations such as diagnosing non-trades, applying surgical edits, and reviewing a portfolio.

The tool inventory is grouped into Build, Check First, Backtest, Edit, Paper Trade, Debug Live, Performance, What’s Tradable, and Answers & Account. Named tools include strategy creation and chunked creation, sample/quickstart/reference retrieval, Markdown and Python validation, keyword lookup, backtesting and sweeps, strategy fetching/updating/patching/export, paper deployment, engine/broker diagnostics, performance and portfolio reports, broker/instrument/list lookups, grounded Q&A, market calendar, account/profile/subscription reads, and Crisp human-support conversation tools.

The page’s build example routes a plain-English weekly NIFTY short-straddle request through sample retrieval, Markdown validation, and creation, returning an editable strategy URL and a dry-run verification marker. The debug example demonstrates a diagnosis that fuses strategy deployment data, the engine notification log, and broker log; it distinguishes an entry condition firing correctly from a broker rejection caused by insufficient margin. The review example lists deployment states such as Active, Paused, Error-Execution, and Exited across live and paper modes.

The debugging section states that the notification log is the engine’s live raw stream, filtered to the user’s strategy and ownership-gated. It can show entries/exits, fired conditions, terminal status, engine errors, broker rejections, orders, statuses, and broker reasons. It cannot show per-candle indicator arithmetic or the live operand values behind a true/false decision because those values are evaluated in memory and are not persisted.

The page exposes an MCP server URL: https://mcp.tradetron.tech/mcp. It says OAuth occurs on Tradetron’s own page, the AI does not see the password, read-only tools work before sign-in, and account-specific writes/logs/deployments/P&L require the OAuth connection. It links to the TT Assistant page and to the downloadable `tt-mcp-instructions.md` rules file.

Observed browser interaction: the initial viewport showed meaningful links for “TT Assistant page,” “Browse the tools,” and “See real responses.” Two downward scroll attempts moved the page offset but browser screenshots were unavailable; text extraction still exposed the same long-page content with later sections truncated by the extractor. No account action, login, connector authorization, or strategy operation was performed.

## MCP instructions file: rendered capture

Source: https://tradetron.tech/mcp-tools/tt-mcp-instructions.md

This is a drop-in persistent instruction file for an AI working with Tradetron MCP. It can be placed in Claude Code as `CLAUDE.md`, in Claude project instructions/project knowledge, in ChatGPT custom instructions or a project, or in another AI’s startup context. The file tells the AI to challenge assumptions, avoid reflexive agreement, and answer directly.

The strategy guardrails are unusually operational. A deployed template shares its definition with the running deployment, so editing it changes live logic. Non-deployed templates may be edited in place; deployed, subscribed, or public templates should be copied first, and confirmation prompts should be respected. The instructions warn not to undeploy/redeploy, to edit the template ID rather than the deployment SID, and to understand how already-fired sets, exits, and added legs behave.

Before building, the AI must ask about exchange and exact symbol, expiry for each leg, exchange clock, lots/quantity, repeat behavior, product type, and exit behavior. Before authoring, it must read the quickstart, authoring reference, keyword definitions, and exchange reference; it must not rely on memory.

Before writing a strategy, the AI must show the strategy Markdown, a plain-English summary, and exactly what differs from the current version, then wait for approval. Validation is distinct from correctness: the mandated sequence is validate Markdown, dry-run/build without saving, create using the dry-run token, then fetch the strategy back and show the stored version. The stored strategy is treated as the executable truth.

Additional guardrails prohibit unrequested Python-block changes, unrequested cleanup, variable names that collide with Tradetron keyword families, multi-change bundling, and guessing through ambiguity. After creation, the user should inspect every condition and leg in Advanced Strategy Builder and paper-deploy before considering live use. The file explicitly says the process should expect iteration rather than present a first draft as final.

The instructions highlight a silent failure mode: wrong or missing keyword arguments can validate and save while producing empty or permanently true/false conditions. Runtime value checks and read-back verification are therefore mandatory. The user-specific setup block asks for exchange, instruments, product type, quantity convention, clock, working templates/deployment state, and a `DO NOT CHANGE` list.

Browser rendering showed encoding artifacts for some Unicode arrows and dashes, but the underlying text was recoverable from direct extraction. The page did not expose meaningful interactive controls beyond its raw Markdown content; no account action was taken.

## FastBT page: rendered and extracted capture

Sources: https://tradetron.tech/fastbt and https://tradetron.tech/fastbt/

The no-slash URL resolved to the trailing-slash canonical URL. FastBT is presented as Tradetron’s replacement backtest engine, intended to predict what a live deployment does for any Strategy Builder-expressible strategy across Indian, US, and crypto markets. The page states that since 25 August 2026 every Tradetron web or AI-chat backtest runs on FastBT.

Headline claims include ₹20 flat per backtest, full available history of 6+ years, walk-forward included, roughly 30 seconds for a 4-year multi-leg positional backtest, up to 486× faster than the previous engine on identical jobs, six market segments, 274.9 million audited option bars with zero OHLC violations, and 60+ report metrics. These are vendor claims from the page and should be treated as claims supported by the page’s linked audits rather than independently verified facts.

The page describes the previous engine’s known problems—long queues, limited history, missing MCX/crypto, and live/backtest keyword differences—and says FastBT replaced it. It says 306 real user jobs were replayed before cutover, no outcomes were lost, about one in five previous-engine runs had produced no fills or report, and FastBT runs fail closed and refund when an honest report cannot be produced.

Capabilities described as shipped include native Custom Python, basket/list strategies, removal of the five-year cap, 86 more cash symbols and ETFs, MCX copper/zinc/aluminium/silver, ₹0 brokerage default, rebuilt missing market days, native option Greeks, automatic refunds for refused runs, and the same fleet for AI-chat backtests. The speed table reports measured paired examples: 18 days at 1-minute from 35 minutes to 4.3 seconds (486×), 6 months at 5-minute from 3h21m to 31s (393×), 2 months at 1-minute from 3h35m to 43s (299×), and 3.7 years hourly from 10h48m to 5m29s (118×). The page also claims a 3.7× median improvement and 42× improvement for the slowest tenth in the 306-job replay.

Coverage is described as minute-level NSE index options, BSE SENSEX/BANKEX, stock options and cash equity, MCX, crypto BTC/ETH, US markets including SPX, India VIX regime data, and strategy forms such as straddles, iron condors, put ladders, directional systems, spreads, covered calls, baskets, and Custom Python.

The integrity layer emphasizes bar-by-bar OHLC audits, repaired holes, removal of ghost expiries, exchange-circular lot sizes, weekly sweeps, replay against 21,011 real live-deployment fills including slippage, deterministic/fail-closed reports, walk-forward verdicts, Probabilistic Sharpe, and Monte-Carlo ranges. Every run is described as an interactive diligence report with 60+ metrics across 20+ sections, including verdict/grade, equity/drawdown, Monte-Carlo, VIX regimes, leg/exit attribution, trades on charts, a cost lab, and raw fills.

Parameter sweeps support up to 4 parameters, up to 10 values each, and up to 16 combinations in one run. Each combination is a full backtest rather than interpolation. Walk-forward can hold out up to 90% of the window; 30% is presented as usual. Variants receive holds-up, degrades, or fails-out-of-sample verdicts. The winner must both perform in-sample and hold up out-of-sample; if none does, the report labels the result least-bad, not deployable. A sample 12-variant NIFTY intraday short-straddle sweep shows all variants profitable in-sample (+6.5% to +21.8%), ten losing out-of-sample, and the best in-sample variant falling to −3.3%, illustrating the anti-overfitting message.

Pricing claims are ₹20 per backtest, any period, with walk-forward free; sweep cost is per variant, so six variants cost ₹120. Failed runs are said to refund automatically. The page compares FastBT with anonymized Indian retail platforms and states that the comparison was compiled from public documentation, pricing pages, and user forums in August 2026; platform names are withheld, so the table is directional marketing rather than a fully auditable competitor study.

The page links to sample reports, a 12-variant sweep report, “One idea, thirteen versions,” TT Assistant, the MCP server, Tradetron universe, a backtest route, and the official “receipts”/audit references. No login, backtest, purchase, or account action was performed.

## TT Assistant page: rendered capture

Source: https://tradetron.tech/tt-assistant/

TT Assistant is positioned as an onboarding page for people who have never used an AI tool. Its central promise is that a trader describes an idea in plain English to ChatGPT, Gemini, Grok, or Claude and receives a real automated, backtested Tradetron strategy without coding. The page frames the product around three gaps: unwritten rules, untested ideas, and no record of why a trade happened. It says the fixes are deterministic strategy rules, audited historical backtesting, and logs that explain trades or skipped trades.

The page translates six terms: LLM as the AI chatbot/brain, MCP as the connector/hands, pseudo-code as rules expressed in sentences, backtest as historical rehearsal, paper trading as live rehearsal with imaginary money, and strategy/algo as the stored plan that watches the market. It maps five actors: the trader supplies the idea, the AI interprets it, the Tradetron MCP executes lookup/validation/create/backtest/log tools, the Tradetron account stores the desk, and the broker holds the money. It states that funds never move to Tradetron or the AI and that going live remains the user’s decision inside Tradetron.

The sample conversation demonstrates a short NIFTY ATM straddle with wings, a profit target, and MTM stop loss. The AI returns the inferred four-leg structure and asks one clarification about fixed strike-distance versus premium-based hedging rather than silently guessing. It then reports illustrative backtest results and later diagnoses a broker margin rejection by fusing engine and broker logs. The page labels the dialogue illustrative.

The “what you can ask” section covers building by description, field-by-field validation before saving, chat-based backtesting with a full report link, engine/broker diagnosis, surgical edits, deployment review, product questions, broker/symbol/holiday lookups, and escalation to human support. It repeatedly states that the AI picks among 47 tools and users do not need to call tools by name.

The connection section gives https://mcp.tradetron.tech/mcp and describes one-time OAuth. It provides setup sequences for ChatGPT (custom connector and Developer mode), Gemini (Connected Apps/custom app, regional rollout caveat), Grok (custom connector), and Claude (custom connector). The page says read-only exploration can work before sign-in, while saving strategies and reading personal logs require the Tradetron sign-in. It links to the MCP tools page, FastBT, a full Claude journey, the Tradetron universe, registration, and the downloadable rules-file concept.

The guardrails section states that the assistant cannot transfer funds, the AI cannot take a strategy live, validation catches wrong types/unknown blocks/dropped rules before saving, and ownership is checked before reading logs or performance. OAuth is described as issuing a revocable permission token rather than exposing the password. The rendered page exposed meaningful top controls “Connect your AI” and “Start from zero”; no connector creation, sign-in, authorization, or trading operation was performed.

## Linked public destinations followed from FastBT / TT Assistant

### Build with Claude case study
Source: https://tradetron.tech/build-with-claude/

The case study presents one options idea taken through thirteen versions in one Claude session. It says Claude challenged ambiguity, built the strategy, backtested it, rejected weak versions, and ended with a paper-deployed structure. The narrative emphasizes three dependencies: Claude’s reasoning, Tradetron MCP’s real keyword definitions/validator/live option chains/account connection, and Tradetron’s strategy language, historical data, and broker execution.

The example begins with a monthly put idea that loses money because winners were capped and losers decayed; an inverted ratio spread is profitable but fragile; a mirror test sums to zero cycle-by-cycle, validating the harness. Four variants show that removing a stop dramatically increases drawdown, taking profit too early caps winners, and adding a new spread every 500 points improves net results without additional drawdown in the example. Extending the sample through COVID reduces the headline CAGR from the shorter-window result and is presented as the more credible figure. The mirrored call structure loses, illustrating regime asymmetry. Ratio tests favor 1 long to 2 short puts over 1:3 on return-to-drawdown. Strike-placement tests favor ATM. A VIX filter hypothesis fails because high VIX is treated as a symptom arriving with losses rather than a reliable precursor. The page’s case study is persuasive product content; its figures remain vendor-provided example results and should not be treated as independently audited investment advice.

### Tradetron Universe
Source: https://tradetron.tech/universe/

The Universe page describes 8,500+ underlyings across 15+ exchanges/venues and six broad asset classes: Indian index options, NSE stock F&O, cash equity, MCX commodities, crypto, and US stocks/index options. It lists NIFTY/BANKNIFTY/FINNIFTY/MIDCPNIFTY, SENSEX/BANKEX, the full NSE F&O list, 2,700+ cash symbols, 60+ MCX underlyings, BTC/ETH across connected venues, and 3,500+ US stocks/ETFs with SPX/NDX/XSP/SPY/QQQ options. It states that live tradability depends on the connected broker/venue and recommends asking the assistant for an authoritative check before building.

The page says named lists can contain up to 500 instruments and strategies can evaluate list members, use screeners, hold many sets and legs, and support re-entries/rollovers. Strategy types include options structures, intraday/positional rules, indicators and price action, TradingView alerts/webhooks, layered risk controls, and security-checked Custom Python. Pricing claims shown are ₹300/strategy/month starting plans, ₹20 per backtest, one free paper-trading deployment for life, and 0% profit share. The page warns that coverage changes, live tradability depends on broker/venue and regulation, backtests are hypothetical, and the content is not investment advice.

The FastBT sample report URLs did not return extractable Markdown in direct retrieval; they remain public links identified on the FastBT page and should be opened visually if detailed report inspection is required. No login, backtest, purchase, or trading action was performed.

## Interactive/link checks

The TT Assistant “Start from zero” control navigated to `https://tradetron.tech/tt-assistant/#words`, confirming it is an in-page onboarding anchor. The “Connect your AI” control was followed/checked against the `#connect` section; the direct anchor exposes the OAuth and guardrail text, but no connector creation or authorization was initiated.

The two FastBT sample-report links were opened read-only. Both returned `401 Authorization Required` from nginx in the current browser/retrieval context, so the report contents could not be inspected. This is recorded as an access limitation, not as evidence that the reports do not exist. The public FastBT page itself describes their intended contents and report navigation.
