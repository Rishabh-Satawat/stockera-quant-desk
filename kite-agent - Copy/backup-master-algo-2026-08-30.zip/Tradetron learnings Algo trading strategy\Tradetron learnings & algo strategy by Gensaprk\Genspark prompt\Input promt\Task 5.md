=========================================================
TASK 5 — FastBT RE-BASELINE OF V7
Deliverables: 09_BACKTESTING.md · 31_TRIAL_REGISTER.md
Prerequisite: Tasks 1-4 complete.
Cost: Rs.20 per backtest. Budget approved: Rs.20 for the
baseline run. ANY further spend requires explicit operator
approval BEFORE the call. State cost before every run.
Inherits all rules from Task 1.
=========================================================

OBJECTIVE
Re-grade the operator's V7 SENSEX weekly iron fly on FastBT
with costs set honestly and walk-forward on, then document
the engine's own biases so every future result is read
correctly. This produces the number every later decision is
measured against.

WHY NOW
The engine changed on 25-Aug-2026. Every prior V7 result
was produced by a different engine under different default
assumptions and is [U]. We are not confirming an old
number; we are establishing a new one.

---------------------------------------------------------
5.1 KNOWN ENGINE BIASES — CARRY THESE INTO EVERY READING
---------------------------------------------------------
Verify each against tradetron.tech/fastbt and the MCP, then
state the operational consequence:

 - STOP EVALUATION. Intrabar stop evaluation against the
   bar's true high and low is BUILT BUT NOT YET LIVE,
   deliberately held back. Until it ships, stops are
   evaluated on candle close. CONSEQUENCE: every stop-loss
   and target result is OPTIMISTICALLY BIASED. Confirm the
   current status — if it went live since, that is the
   headline of this task.
 - DEFAULT COSTS. Brokerage now defaults to Rs.0 and
   slippage to 0.05% (previously 1%). A run left on
   defaults understates costs. SET BOTH EXPLICITLY.
 - HISTORICAL LOT SIZE. FastBT applies the lot size in
   force on each trade date. A multi-year run silently
   changes position size. Any fixed-rupee threshold means
   a different move in different years.
 - COVERAGE. FastBT declines constructs it cannot
   faithfully simulate rather than mis-booking them;
   roughly a third of real traded volume remains not
   honestly backtestable. Run tt_check_backtestability on
   V7 FIRST and report exactly which constructs, if any,
   are declined. A declined construct means the backtest is
   not testing the strategy the operator deployed.
 - MIXED EXPIRY REGIME. Any window spanning Sep-2025
   contains the SEBI expiry-day migration. Per Task 3, know
   which weekday applied when.

---------------------------------------------------------
5.2 PRE-REGISTER THE RUN — BEFORE YOU SPEND
---------------------------------------------------------
Write the entry into 31_TRIAL_REGISTER.md BEFORE calling
the backtest. It cannot be reconstructed afterwards and a
register written after the fact is worthless.

Record: date, strategy id and version, exact period, every
cost parameter, walk-forward configuration, in-sample and
out-of-sample split, and — critically — THE HYPOTHESIS AND
THE PASS/FAIL THRESHOLD, stated numerically, BEFORE the
result is known.

Publish gate values before running. No moving goalposts.
If the result lands just outside a gate, that is a fail,
not a reason to revisit the gate.

---------------------------------------------------------
5.3 THE RUN
---------------------------------------------------------
Configuration:
 - full available history (6+ years is advertised; report
   what SENSEX weekly options actually have — BSE weekly
   data will be shorter than the headline and the real
   start date is a finding)
 - brokerage set explicitly to Rs.20 per order. Confirm
   whether that is per order or per leg, and whether a
   four-leg entry plus four-leg exit counts as 8 orders.
   Getting this wrong misstates cost by a factor.
 - slippage set explicitly. Justify the number. Do NOT
   accept 0.05% silently — SENSEX weekly options,
   particularly the wings, are not that tight. State your
   assumption and mark it [I] until Task 12 gives real
   bid/ask.
 - walk-forward ON
 - Monte-Carlo included if available at no extra cost

Report the raw output in full. Do not summarise away the
uncomfortable numbers.

---------------------------------------------------------
5.4 THE EXIT-ATTRIBUTION TABLE — THE REAL DELIVERABLE
---------------------------------------------------------
The headline P&L is the least useful number in the report.
Produce: for every closed trade, WHICH exit row fired.

Then: if one exit row dominates, that row IS the strategy.
A wide tail-risk guard that turns out to be the primary
exit path is not protecting the strategy — it is the
strategy, and it was never designed as one. Say so
directly if the data shows it.

Cross-check the count of trades against the number of
expiries in the period. A weekly strategy over N weeks
should produce roughly N entries. A large shortfall means
entries are silently not firing, which is a Task 1 Q10
failure mode, not a performance result.

---------------------------------------------------------
5.5 READ THE REPORT PROPERLY
---------------------------------------------------------
FastBT publishes 60+ metrics with Monte-Carlo ranges,
walk-forward verdicts and VIX-regime breakdowns. Extract
and interpret, in this order:
 1. out-of-sample versus in-sample — if OOS is materially
    worse, nothing else in the report matters
 2. walk-forward verdict
 3. maximum drawdown and time to recover, in rupees and in
    percent of margin actually blocked
 4. profit factor, and average win against average loss.
   For premium selling, win rate alone is meaningless and
   must never be quoted without the ratio beside it.
 5. consecutive-loss distribution — the operator needs to
    know the worst streak he must sit through
 6. per-VIX-regime breakdown — does the edge exist in all
    regimes or one?
 7. margin over time, so return is on capital actually
    blocked, not on notional

---------------------------------------------------------
5.6 NO SWEEPS IN THIS TASK
---------------------------------------------------------
Do not run tt_backtest_sweep. Do not propose variants. Do
not optimise. This task establishes ONE honest baseline.

Rationale to record: Tradetron's own published example
shows ten of twelve variants that looked profitable
in-sample losing out-of-sample. Sweeping before a baseline
exists means you cannot tell improvement from selection
noise. Sweeps are Task 10, after validation discipline is
fixed in Task 8.

If the baseline is unprofitable, that is the correct output
of this task. Report it plainly and do not soften it.

---------------------------------------------------------
STOP AND REPORT
---------------------------------------------------------
a) files written; rupees spent, itemised
b) tt_check_backtestability output — what was declined
c) the pre-registered hypothesis and gate, then the result
   against it: PASS or FAIL, one word, first
d) the exit-attribution table
e) trade count versus expected expiry count
f) the seven metrics from 5.5
g) how the new number differs from the previously recorded
   result, and how much of the difference is engine change
   versus cost change versus real
h) an explicit list of every result that is distorted by
   the candle-close stop bias, and in which direction
i) SELF-REVIEW section

Close with the standing question.
