# Tradetron Keyword Master and Condition-Builder Blueprint

**Author:** Manus AI  
**Primary purpose:** AI-agent memory for converting plain-English strategy requirements into exact, reviewable Tradetron condition-builder and position-builder blueprints.

## 1. Evidence, precision, and use boundary

This master file is based primarily on Tradetron’s official [Keyword Documentation](https://tradetron.tech/keyword/documentation), supplemented by Tradetron’s official explanation of keywords, its ORB help article, its Initialize Variables article, and its Leg Exit article. [1] [2] [3] [4] The exact documentation capture is included as a separate supporting Markdown file because the official page contains hundreds of example images and long keyword sections whose surrounding wording should remain available for exact retrieval.

The document has four evidence levels. **Exact documented syntax** means a keyword name, parameter rule, output type, formula, warning, or example is transcribed from the official documentation. **Blueprint rule** means a deterministic construction procedure derived from those documented semantics. **AI interpretation** means a practical safeguard or clarification rule proposed for agent behavior. **Unverified/current-state item** means a product behavior that should be rechecked in the live Tradetron interface before execution.

This is an engineering and documentation reference, not investment advice. A syntactically valid condition can still express the wrong trading idea. The agent must ask clarifying questions, show the proposed structure, validate it, and require human review before saving, paper deployment, or live deployment.

## 2. The core mental model

Tradetron keywords are pre-programmed functions. A keyword receives inputs, performs a defined operation, and returns a value that can be compared, combined, or passed into another keyword. The official explanation describes the builder as a way to create conditions such as `SBIN CLOSE(-2) > SBIN OPEN(-2)` without writing a general-purpose program. [2]

Data is organized into candle positions. In the official example, the ongoing candle is position `0`; when the candle closes, it becomes `-1`, and earlier candles move further left. Therefore `Position(CLOSE, -1)` means the most recently completed candle, while `Position(CLOSE, 0)` refers to the current candle and is equivalent to current data such as LTP in the relevant context. Position inputs cannot be positive. [2] [1]

A condition normally has a left operand, a comparison operator, and a right operand. Operands can be constants, simple keywords, nested keywords, position series, indicator outputs, strategy-state outputs, dates, times, or formulas. Logical operators such as `AND` and `OR` combine rows into a set condition. The agent must preserve type compatibility: numeric outputs compare with numeric outputs; date strings compare with date strings; Boolean outputs should not be silently treated as prices.

### Canonical condition shape

```text
LEFT_OPERAND  COMPARATOR  RIGHT_OPERAND

Examples:
Position(CLOSE, -1, 5m, NFO:NIFTY 50) > Position(EMA, -1, 5m, NFO:NIFTY 50)
LTP(NFO:NIFTY 50) > ORB(NFO:NIFTY 50, HIGH, 09:15, 09:30)
Today(NFO:NIFTY 50) = Current Week Expiry(NFO:NIFTY 50)
PNL() * Multiplier() >= Number(500)
```

The examples above illustrate structure. The exact field selectors and nesting must be created through the live builder rather than guessed from text.

## 3. Mandatory AI intake schema

Before writing any Tradetron blueprint, the agent must collect the following information. If an omitted value can change the resulting trade, it is not optional.

| Dimension | Required questions |
|---|---|
| Market | Which exchange, segment, venue, and exact underlying? Is it spot, future, option, cash equity, MCX, CDS, crypto, or another supported asset? |
| Time | Which exchange clock and time zone? Which candle timeframe? Which entry window and universal exit time? |
| Instrument | Exact exchange, underlying/list, expiry convention, option type, strike method, quantity, and product type. |
| Entry | Which condition rows? Which operators? What should be evaluated on the current candle versus a completed candle? One-time or repeat? |
| Position | Every leg’s side, segment, expiry, strike, quantity, hedge relationship, and execution order. |
| Exit | Leg-level or strategy-level? Target/stop base: points, rupees, percentage, MTM, premium, or capital? Trailing or fixed? |
| State | Re-entry, repair, wait-and-trade, runtime variables, maximum attempts, reset behavior, and universal exit. |
| Testing | Date range, candle size, trade price, expiry handling, charges, slippage, capital, multiplier, and walk-forward/out-of-sample requirement. |
| Deployment | Paper or live? Broker connection, authentication/token requirements, margin, monitoring, and failure response. |

If two interpretations would produce different instruments or orders, the agent must stop and ask rather than select a default.

## 4. Instrument Name: the five-level identity

The official documentation describes `Instrument Name` as a highly versatile nested keyword with five distinct inputs: **Exchange, Underlying, Expiry, Option type, and Strike Price**. [1]

| Level | Exact design responsibility |
|---|---|
| Exchange | Select the correct venue/segment, such as NSE, NFO, MCX, CDS, BITBNS, FX, or NASDAQ-eq where supported. Cash equity generally uses NSE; futures/options generally use NFO. |
| Underlying | Select one underlying or a list. For an index through NFO, the selected underlying can provide the relevant spot context. |
| Expiry | Select current/next week or current/next month, or an appropriate derivative expiry offset. Offset `0` denotes the current selected expiry and `1` the next. Confirm asset-specific availability. |
| Option type | `CE` or `PE` for options. Do not invent an option type for futures or cash instruments. |
| Strike Price | Fixed strike or dynamic rule such as `ATM`, `ATM SPOT`, `Find Strike`, `Get Strike`, `Max OI Strike`, or a formula. |

The agent must produce an instrument identity table before producing condition rows. A blank or incorrectly spelled instrument selector can prevent execution even when the rest of the strategy is logically correct.

### ATM versus ATM SPOT

`ATM` is based on the futures chart, while `ATM SPOT` is based on the spot value. The official example rounds a value of 17,480 to 17,500 and shows `+2` as two strikes away, yielding 17,600 under the demonstrated strike interval. [1] The AI must ask whether the user means futures-based or spot-based ATM before selecting a strike.

### Find Strike

`Find Strike` selects a strike according to a target value such as a premium and a filter such as `GREATER`, `LESSER`, or `ANY`. The official example selects the NIFTY 50 weekly CE nearest to ₹150 and explains that `LESSER` restricts the result below the target while `ANY` returns the nearest available value. The documentation says the function supports particular index/expiry combinations, is not compatible with MCX and MIDCP indices, and searches a dataset of 50 strikes above and 50 below the daily ATM calculated from the current day’s opening price. Out-of-range requests can return `none`. [1]

The agent must treat `Find Strike` as a constrained lookup, not as a guaranteed universal strike resolver. It should check the underlying, expiry, option type, target direction, supported index, and possible `none` output.

### Get Strike and Max OI Strike

`Get Strike` returns a strike based on a configured value or condition and is generally used in Strike FX. `Max OI Strike` returns the numeric strike with maximum open interest at that instant and is documented as currently available for indices. [1] The agent must distinguish a premium-selected strike from an open-interest-selected strike and must not substitute one for the other.

## 5. Position keyword and series semantics

`Position` is the main series access wrapper. It takes a series or indicator and a candle position. `0` is the current candle; `-1` is the previous candle; `-2` is the candle before that. [1] [2]

Most OHLC and technical indicators are used inside `Position`. The nested structure must preserve:

```text
Position(
  series_or_indicator,
  candle_position,
  timeframe,
  instrument_symbol,
  optional_candle_type,
  indicator_parameters
)
```

The agent must not fabricate parameter order. It should use the live keyword selector or exact documentation example for the selected keyword, then echo the chosen inputs in the blueprint.

### Current versus completed data

A condition that uses position `0` can read an ongoing candle or current value. A condition that is intended to use a completed candle should normally use `-1` or another negative offset. For ORB and time-specific keywords, the agent must also ensure that the data window has completed before evaluating the condition.

### Nested series operations

The documentation provides array/series operators such as `Add Array`, `Subtract Array`, `Multiply Array`, `Divide Array`, and `Power`, and series-aware operators such as `Math Series Operation`, `OHLC Spread`, and `OHLC Sum`. [1] These are not interchangeable with scalar math. The agent must label every operand as **scalar** or **series** before constructing a formula.

## 6. Keyword taxonomy and exact documented behavior

The following taxonomy is an AI retrieval index. The official spelling is preserved as shown by the documentation; variants such as `Bolinger` and `Donchain` should not be silently corrected when entering the product selector.

### 6.1 Scalar math and constants

| Keyword | Documented role and exact caution |
|---|---|
| `Absolute` | Returns the positive value of its input. Useful when the sign should be discarded. |
| `Number` | Returns the numeric value entered by the user. Use for thresholds and constants. |
| `Math Operation` | Performs a mathematical operation on two inputs and returns a float; can be used with `Round`. |
| `Max` / `Min` | Return the maximum/minimum of two inputs. Series operands require the `Position` context. |
| `Add Array` / `Subtract Array` | Add/subtract a value from the entire selected series. |
| `Multiply Array` / `Divide Array` | Multiply/divide the entire selected series by a value. |
| `Power` / `Sqrt` | Raise or square-root a selected series. |
| `Log` / `Log Return` | Return logarithm or log return for a selected series; documentation references NumPy. |
| `Ratio` | Returns the ratio of two series inputs. |
| `Round` | Rounds a value to the selected base, such as the nearest 50. |
| `Multiplier` | Returns the deployment multiplier and scales values for a selected deployment multiplier. |
| `Random Number(0.00-1.00)` | Returns an absolute decimal random number from 0 to 1.00. Use only when nondeterminism is explicitly intended. |

The agent must apply BODMAS and use explicit grouping when a target/stop formula contains multiple operations. Tradetron’s official keyword article specifically notes that brackets can make conditions easier to understand. [2]

### 6.2 Market data and price fields

`LTP` returns last traded price. The documentation explains that selecting NFO and `NIFTY 50` without an expiry can be used for spot context, while selecting current-month expiry returns the futures price. [1] `Bid Price` and `Ask Price` return the best bid/ask, but if the value has not changed from the last tick, the documentation says the fallback can be LTP. `Bid Ask Diff` returns the best bid minus best ask and may return `0` when there is no bid/ask change.

`OPEN`, `HIGH`, `LOW`, `CLOSE`, `Previous Close`, `Change`, and `Change%` provide price fields. `Change%` expects a plain number such as `2` or `-2`; do not add a `%` sign. `Volume` returns cumulative volume for the current day up to the check time, while `Volume series` returns volume for a selected candle and cannot be used on spot indices without volume. `Traded Value` returns total turnover. `Tick Size` and `Lot Size` return exchange/instrument-specific sizing data.

### 6.3 Trend, momentum, volatility, and volume indicators

The documentation lists the following indicator keywords, generally used under `Position` unless otherwise stated: `ADX`, `ADX Smooth`, `Alligator`, `ALMA`, `AROONDOWN`, `AROONUP`, `ATR`, `Awesome Oscillator`, `Balance of Power`, `BBPercentage`, `Bolinger Band width`, `CCI`, `Chaikin Money Flow`, `Choppiness Index`, `CMO`, `Coppock Curve`, `DEMA`, `DI-`, `DI+`, `Donchain Ch Lower`, `Donchain Ch Middle`, `Donchain Ch Upper`, `Donchain Ch Width`, `DTI`, `EMA`, `Fisher Transform`, `Harmonic Mean`, `Hull MA`, `Kaufman Adaptive MA`, `Kaufman Efficiency indicator`, `Keltner Channels`, `Keltner Close`, `LINEARREG`, `LINEARREG SLOPE`, `LINEARREG_ANGLE`, `LINEARREG_INTERCEPT`, `LSMA`, `MACD`, `Macdhist`, `Macdsignal`, `Mean`, `Median`, `MFI`, `OBV`, `Percentage Price Oscillator`, `Percentile Rank`, `Pivot Point`, `ROC`, `ROCP`, `RSI`, `RSI Series`, `SAR`, `SMA`, `ST SMA`, `Stdev`, `StochD`, `StochK`, `StochRsiD`, `StochRsiK`, `SUPERTREND`, `TEMA`, `TR`, `TRIMA`, `TRIX`, `Typical Price`, `Ultimate Oscillator`, `Volume Price Trend`, `Vortex VI-`, `Vortex VI+`, `VWAP`, `VWAP Series`, `VWMA`, `WILLR`, `WMA`, `Zero Lag EMA`, and `Zscore`. [1]

The agent must ask for every required indicator parameter. Examples from the documentation include period, series, timeframe, multiplier, channel line, or oscillator line. `RSI` requires a period of at least 2; `RSI Series` can apply RSI to series such as OPEN, HIGH, or EMA, while `RSI` uses close as its default. `Pivot Point` supports Standard, Fibonacci, and Camarilla and is documented with a daily-timeframe caution. `HV` outputs from 0 to 1 and should be multiplied by 100 when comparing against percentage IV.

### 6.4 Candle-pattern and candle-type keywords

Candle-pattern keywords include `DRAGONFLY DOJI`, `DOJI`, `ENGULFING`, `GRAVESTONE DOJI`, `HAMMER`, `HANGINGMAN`, `HARAMI`, `INVERTED HAMMER`, `MORNINGDOJISTAR`, `MORNINGSTAR`, and `SHOOTINGSTAR`. The documentation states these are intended for `Position` and references TA-Lib. The agent must specify candle offset, timeframe, instrument, and candle type.

Tradetron supports candle-type transformations such as Heikin Ashi, Line Break, and Renko. `Renko` uses a fixed brick size; `Renko - closed candle` skips the ongoing brick to reduce repainting risk; `Renko dynamic bricks` can use a formula such as ATR for brick size. [1] The agent must explicitly declare whether the strategy uses an open/current transformed candle or a closed transformed candle.

### 6.5 Date and time

| Keyword | Exact output/behavior |
|---|---|
| `Time` | Current time as integer `HHMM`; no colon or special characters. |
| `Sec` / `Minute` / `Hour` | Current seconds, minutes, or hour as integers. The documentation warns against formatted strings such as `17:00`. |
| `Day` / `Month` / `Year` | Current day of month, month number 1–12, or current year. Use positive integers. |
| `Week` | Current week number of the year. |
| `Week Day` | Monday = 1 through Friday = 5. |
| `Year Day` | Current day number from the beginning of the year. |
| `Now` | Current date/time as integer `YYYYMMDDHHMM`. |
| `Today` | Current date as string `YYYY-MM-DD`. |
| `Tomorrow` | Next date as string `YYYY-MM-DD`. |
| `Date` | A specified date as string `YYYY-MM-DD`. |
| `Next Trading Day` | Next trading date as string; compare only against another string date. |
| `Days Difference (D2-D1)` | Integer difference; D2 must be the larger date and calendar days include holidays/non-trading days. |
| `Current Week Expiry` | Current weekly expiry as `YYYY-MM-DD`; do not use for stocks without weekly expiries. |
| `Current Month Expiry` | Current monthly expiry as `YYYY-MM-DD`. |
| `Previous Expiry` | Last historical expiry with a non-negative offset. |
| `MCX Fut Expiry` / `MCX Option Expiry` | MCX derivative expiry date helpers with asset-specific use. |

Date keywords return strings and must be compared with compatible string outputs. Time keywords return integers. This is one of the most common type errors the agent must catch.

### 6.6 Options, Greeks, open interest, and synthetic data

`Delta`, `Gamma`, `Theta`, `Vega`, and `Rho` return the corresponding Greek for a selected option, often referenced through a traded leg. `Delta Neutral`, `Gamma Neutral`, `Theta Neutral`, and `Vega Neutral` return the quantity required to neutralize the selected Greek for the underlying, in lot-size multiples and often used in QTY FX.

`Net Delta`, `Net Gamma`, `Net Theta`, and `Net Vega` aggregate the corresponding Greek across open positions for the selected underlying. The documentation defines the sign convention for long/short CE and PE in `Net Delta`; the agent must not assume all Greeks have the same sign interpretation without checking the instrument and position side.

`PCR` returns put-call ratio based on open interest; `Total OI` returns total open interest for an option type; `Max OI Instrument` returns the instrument with maximum OI; and `Max OI Strike` returns its strike. These are documented as currently available for indices where specified. `Synthetic Futures` calculates put-call parity for the current week and can be used for arbitrage-oriented calculations or synthetic ATM logic.

### 6.7 Strategy-state and trade-reference keywords

| Keyword | Scope and critical behavior |
|---|---|
| `EntryDate` | Latest date on which selected underlying entry legs executed; string `YYYY-MM-DD`. |
| `EntryTime` | Latest entry time as integer `HHMM`. |
| `EntryPrice` | Latest entry price of selected instrument; useful for SL/target comparisons and list strategies. |
| `EntryUnderlyingPrice` | Underlying spot at the time of option entry; useful for index-movement stops. For NSE equity, documentation says it equals EntryPrice. |
| `LastRepairedDate` | Date of latest repair execution. |
| `LastRepairedTime` | Time of latest repair as `HHMM`. |
| `LastRepairedPrice` | Price of the instrument at the latest repair/exit update. |
| `LastRepairedUnderlyingPrice` | Underlying price captured at latest repair/exit update. |
| `Open positions` | Returns `1` if a selected instrument is open and `0` otherwise, but the documentation warns it can return `3` after three unique entries even if only one position is currently open; do not use it as a re-entry-count limiter. |
| `PNL` | Strategy-level PNL for the counter; if used in Universal Exit it can close the whole strategy and resets only after Universal Exit. |
| `PNL Underlying` | PNL for the selected underlying, commonly used in Set Exit to close that underlying while leaving others. |
| `Max Loss` | Maximum realized/unrealized strategy loss during one run counter; commonly multiplied by `Multiplier` in Universal Exit. |
| `Max Profit` | Maximum strategy profit during one run counter; can be combined with PNL to create custom trailing logic. |
| `Required Capital` | Reads the strategy’s Capital Required setting and should be used with `Multiplier`. |
| `Traded Value` | Total turnover of the selected instrument. |

### 6.8 Traded Instrument and Traded Instrument Name

`Traded Instrument` can return **PRICE, QUANTITY, STRIKE, PNL, or TIME** for a referenced leg and can be used in both condition and position builder contexts. The documentation gives the PNL formula as:

```text
(LTP - Entry Price) * Qty Traded
```

The reference requires a set number, condition number, and leg number. Entry is condition 1; subsequent repair conditions are numbered in sequence. The leg number follows the order of positions in the Position Builder. `Traded Instrument Name` returns the instrument name and is normally nested inside LTP, EMA, or another indicator to apply that operation to the referenced leg. [1]

The agent must always print the resolved reference in human language, for example: `Set 1 → Entry condition 1 → Leg 2 → Traded Instrument PNL`, and must not confuse a condition number with a leg number.

### 6.9 Position Detail and aggregate quantity

`Position Detail` is strategy-level and has four filters—Condition Type, Transaction Type, Instrument Type, and Underlying—and three selectable outputs: Value, Quantity, and Count. It scans the strategy rather than only the set in which it appears. [1]

The documentation demonstrates three uses: allow only one active straddle set by testing net quantity, allow a long straddle to enter only once by checking Entry + Buy quantity, and limit list entries by Count. It warns that simultaneous qualifying stocks can all enter before the next check, so a count condition alone is not a mathematically foolproof cap. For options, different strike/expiry/type combinations are unique instruments.

`Net Quantity` is also strategy-level. It reads the referenced instrument and scans the entire strategy; it is not a set-level or position-level keyword. This distinction must be displayed in any generated blueprint.

## 7. Risk, exits, and trailing behavior

### Leg Exit

`Leg Exit` takes an instrument, set, condition, leg number, and target or stop-loss expressed in percentage or points. The builder automatically considers whether the position is long or short, and the leg exits when whichever configured condition becomes true first. [1] [4]

**Critical official limitation:** `Leg TSL`, `Leg Exit`, and `Leg SL Trail` are intended only for legs that trade once. The documentation explicitly warns that they do not work correctly with re-entries and may fail or loop if the same leg re-enters from the same position. The AI must block re-entry for any leg using these set-exit keywords or use a different custom state design.

### Leg SL trail and Leg TSL

The documentation distinguishes points from percentage. For `Leg SL trail`, SL Points are points, not rupees, and SL Percentage is a percentage. `Leg TSL` uses activation, lock profit, increase profit by, and increase TSL by. The example describes a put bought at 100 with a 20-point activation: trailing begins after price moves above 120, and a lock-profit rule can exit if price falls back. [1]

The agent must state whether each trailing parameter is points, rupees, or percentage and must specify the activation threshold and ratchet increment. It must also detect re-entry incompatibility.

### Universal Exit TSL

`Universal Exit TSL` is strategy-level. Its inputs are TSL type, activation, lock profit, increase profit by, and increase TSL by. The documentation says points are based on rupees in PNL, percentage is based on the capital mentioned, and **all values must be based on a 1X multiplier**. [1] The agent must not silently multiply these values again when a deployment multiplier is used.

### PNL and Max Profit custom trailing

A custom strategy-level trailing design can compare `Max Profit` with current `PNL`. The documented example activates after max profit exceeds 2,500 and exits when `Max Profit - PNL` exceeds 1,000, with both scaled by `Multiplier`. [1] The agent must expose the activation and drawdown-from-peak thresholds as separate parameters.

## 8. ORB, time gates, and signal timing

The official ORB article states that ORB fetches Open, High, Low, Close, or Volume over a user-defined time window and must be evaluated only after the window has fully passed. It recommends two AND-connected rows: a time gate and the actual breakout condition. [3]

```text
Row 1: Time > ORB window end
Row 2: LTP > ORB(Instrument, High, Window Start, Window End)
Join: AND
```

The agent must never generate an ORB breakout condition without a time gate. It must also specify exchange time zone, range start/end, price field, candle timeframe if applicable, and whether the breakout is one-time or repeatable.

`Indicator Value (Time)` is standalone rather than under Position. It retrieves an indicator value at a particular time and must be evaluated after that time has passed. The official documentation recommends grouping it with an AND time condition. `Value When` captures the value of an indicator/series at the candle where a crossover occurred; it supports `-n from Last` and requires the compared indicators to use the same candle type/timeframe. `VWAP Series` is not supported inside `Value When`. [1]

## 9. Runtime variables and initialization

`Init Var` creates a variable and assigns a name and number. The documentation says it runs only once per run counter and is useful with Python or condition-action coding. Names and values are case- and space-sensitive. `Get Runtime` retrieves a runtime variable that may be a string or number; `Get Runtime Number` retrieves a numeric runtime value and is useful where a numeric input is required, such as a strike lookup. [1]

The official help article adds an important lifecycle rule: Initialize Variables are written when a new run counter starts and a bot is assigned, not when a trade executes. They are written only once per run counter, may not appear in Runtime Data until a trade occurs, and are not rewritten the next day if the same run counter remains active. The article also states that Initialize Variables cannot be used for list-based strategies. [5]

The AI must include this variable lifecycle block whenever variables appear:

```text
Variable name: exact case and spaces
Type: string / number / instrument / strike / other
Initialization event: first bot assignment in new run counter
Read keyword: Get Runtime / Get Runtime Number
Write/update event: exact condition or action
Reset event: exit, new run counter, or explicit action
List-based strategy: allowed / not allowed
```

## 10. Blueprint output contract for the AI agent

When the user asks in plain English for a strategy, the agent must respond with the following sections before producing a final implementation.

### A. Intent normalization

Rewrite the request into market, instrument, timeframe, entry, position, exit, risk, re-entry, sizing, and deployment requirements. Mark every missing field.

### B. Instrument identity table

Print exchange, underlying/list, expiry, option type, strike selector, quantity, and product type for every leg.

### C. Condition-builder rows

Use a table with exact row number, block (`Entry`, `Set Exit`, `Repair Once`, `Repair Continuous`, `Universal Exit`), left operand, comparator, right operand, type, timeframe, candle offset, and plain-English meaning.

### D. Position-builder rows

Use a table with set, condition, leg, transaction side, instrument, expiry, strike, quantity, entry/exit relation, and execution behavior.

### E. State machine

Describe entry, fill, stop, target, repair, re-entry, reset, and universal-exit states. Include all runtime variable names exactly.

### F. Backtest specification

Record date range, candle frequency, trade price, expiry behavior, costs, slippage, capital, multiplier, report metrics, and out-of-sample/walk-forward split.

### G. Validation checklist

Check exact keyword spelling, type compatibility, positive/negative date/time conventions, instrument resolution, expiry availability, position offsets, re-entry compatibility, leg numbering, strategy-versus-set scope, multiplier scaling, and universal exit.

### H. Approval gate

Show the exact proposed structure, a plain-English rendering, unresolved assumptions, and differences from the current strategy. Do not save or deploy until the user approves.

## 11. Deterministic rendering rules

The natural-language renderer should use stable sentences:

```text
At [time gate], evaluate [left operand] [operator] [right operand] on [instrument] using [timeframe] and candle offset [offset]. If true, execute [set/condition] with [leg list]. Exit using [scope], [metric], [threshold], and [time fallback]. Re-entry is [enabled/disabled]; if enabled, it is armed by [state], limited to [count], and reset by [event].
```

Never render a formula without its unit. For example, say “₹500 strategy PNL” rather than “500 target,” and “20 points of leg trailing activation” rather than “20 TSL.”

## 12. High-risk error catalogue

| Error | Why it is dangerous | Required AI response |
|---|---|---|
| Using `17:00` in `Time` | Time expects integer `HHMM`. | Convert only after confirming intended time; render `1700`. |
| Comparing `Today` to `Number` | Date keywords return strings. | Use another date-string keyword such as expiry. |
| Using current ORB before range ends | Produces incomplete breakout level. | Add an AND time gate after the range. |
| Using `Open positions` as re-entry count | Re-entry history can produce unexpected counts. | Use Position Detail or explicit state. |
| Using `Leg Exit` with re-entry | Official documentation warns of failure/loops. | Block re-entry or redesign exit logic. |
| Treating `PNL` as set-local | PNL remains strategy-level even in Set Exit. | Use PNL Underlying if underlying-level exit is intended. |
| Confusing `ATM` with `ATM SPOT` | Futures and spot can produce different strikes. | Ask which reference is intended. |
| Confusing set/condition/leg references | Can read or exit the wrong leg. | Print full reference path and verify in builder. |
| Forgetting `Multiplier` | Targets/stops may not scale with deployment size. | State scaling policy explicitly. |
| Assuming initialization is daily | Init Var runs once per run counter. | Define run-counter/reset lifecycle. |
| Assuming validation proves semantics | Wrong parameters can still encode the wrong logic. | Dry-run, save, read back, and compare. |

## 13. Exact keyword catalogue

The official selector currently exposes the following names in its documentation page. Preserve spelling and capitalization when matching a builder choice:

```text
Absolute; Add Array; ADX; ADX Smooth; Alligator; ALMA; AROONDOWN; AROONUP;
Ask Price; ATM; ATM SPOT; Atmiv; ATR; Awesome Oscillator; Balance of Power;
BBPercentage; Bid Ask Diff; Bid Price; Bolinger Band width; CCI; Central Pivot Range;
Chaikin Money Flow; Chandelier Exit; Change; Change%; Choppiness Index; CLOSE; CMO;
Coppock Curve; correl; Cross; Current Month Expiry; Current Week Expiry; Date; Day;
Days Difference (D2-D1); Delta; Delta Neutral; DEMA; DI-; DI+; Divide Array;
Donchain Ch Lower; Donchain Ch Middle; Donchain Ch Upper; Donchain Ch Width;
DRAGONFLY DOJI; DTI; EMA; ENGULFING; EntryDate; EntryPrice; EntryTime;
EntryUnderlyingPrice; Find Strike; Fisher Transform; Futures; Gamma; Gamma Neutral;
Get Runtime; Get Runtime Number; Get Strike; GRAVESTONE DOJI; HAMMER; HANGINGMAN;
HARAMI; Harmonic Mean; Heikin Ashi; HIGH; Highest High Value; Hour; Hull MA; HV;
Indicator Value (Time); Init Var; Instrument Name; INVERTED HAMMER; Iv;
Kaufman Adaptive MA; Kaufman Efficiency indicator; Keltner Channels; Keltner Close;
LastRepairedDate; LastRepairedPrice; LastRepairedTime; LastRepairedUnderlyingPrice;
Leg Exit; Leg SL trail; Leg TSL; Line Break; LINEARREG; LINEARREG SLOPE;
LINEARREG_ANGLE; LINEARREG_INTERCEPT; Log; Log Return; Lot Size; LOW; Lower Bolinger;
Lowest Low Value; LSMA; LTP; MACD; Macdhist; Macdsignal; Math Operation;
Math Series Operation; Max; Max Loss; Max OI Instrument; Max OI Strike; Max Profit;
MCX Fut Expiry; MCX Option Expiry; Mean; Median; MFI; Min; Minute; Month;
MORNINGDOJISTAR; MORNINGSTAR; Multiplier; Multiply Array; Net Delta; Net Gamma;
Net Quantity; Net Theta; Net Vega; Next Trading Day; Now; Number; OBV; OHLC Spread;
OHLC Sum; OPEN; Open positions; ORB; PCR; Percentage Price Oscillator; Percentile Rank;
Pivot Point; PNL; PNL Underlying; Position; Positions Detail; Power; Previous Close;
Previous Expiry; Random Number(0.00-1.00); Ratio; Renko; Renko - closed candle;
Renko dynamic bricks; Required Capital; Rho; ROC; ROCP; Round; RSI; RSI Series; SAR;
Sec; SHOOTINGSTAR; SMA; Sqrt; ST SMA; Stdev; StochD; StochK; StochRsiD;
StochRsiK; Subtract Array; Sum; SUPERTREND; Symbol; Synthetic Futures; TEMA; Theta;
Theta Neutral; Tick Size; Time; Today; Tomorrow; Total OI; TR; Traded Instrument;
Traded Instrument Name; Traded Value; TRIMA; TRIX; Typical Price; Ultimate Oscillator;
Universal Exit; TSL; Upper Bolinger; Value When; Vega; Vega Neutral; Volume;
Volume Price Trend; Volume series; Vortex VI-; Vortex VI+; VWAP; VWAP Series; VWMA;
Week; Week Day; WILLR; WMA; Year; Year Day; Zero Lag EMA; Zscore
```

The separate exact-capture attachment preserves the original page’s full keyword prose and image references. Use this catalogue for retrieval, but always use the live builder to confirm any field names or newly added keywords.

## References

[1]: https://tradetron.tech/keyword/documentation "Tradetron Keyword Documentation"
[2]: https://tradetron.tech/blog/keywords-in-tradetron "Keywords in Tradetron"
[3]: https://help.tradetron.tech/en/article/how-to-use-the-orb-keyword-in-the-strategy-builder-1lrhg22/ "How to Use the ORB Keyword in the Strategy Builder"
[4]: https://help.tradetron.tech/en/article/how-to-use-leg-exit-keyword-on-tradetron-1rnyke4/ "How to use Leg Exit keyword on Tradetron"
[5]: https://help.tradetron.tech/en/article/initiate-variables-feature-1axm72v/ "Initiate Variables Feature"
[6]: https://help.tradetron.tech/en/article/runtime-variables-in-tradetron-capture-once-use-anywhere-83nahv/ "Runtime Variables in Tradetron"
