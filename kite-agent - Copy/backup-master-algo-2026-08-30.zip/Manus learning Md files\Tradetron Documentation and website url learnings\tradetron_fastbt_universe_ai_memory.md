# Tradetron FastBT, Universe, and Claude Case Study — AI Memory

## Purpose of this memory file

This file consolidates the public FastBT page, its linked Tradetron Universe page, and the linked “One idea, thirteen versions” case study. It is designed for retrieval by an AI that needs to understand Tradetron’s backtesting story, market coverage, workflow, pricing claims, and evidence boundaries.

## Sources and URL behavior

| Source | URL | Result |
|---|---|---|
| FastBT landing page | [tradetron.tech/fastbt](https://tradetron.tech/fastbt) | Redirected to the trailing-slash canonical URL and reviewed. |
| FastBT canonical page | [tradetron.tech/fastbt/](https://tradetron.tech/fastbt/) | Public product/evidence page. |
| Tradetron Universe | [tradetron.tech/universe/](https://tradetron.tech/universe/) | Public market-coverage and pricing page. |
| Claude case study | [tradetron.tech/build-with-claude/](https://tradetron.tech/build-with-claude/) | Public narrative of one strategy through thirteen versions. |
| Sample report | [FastBT sample report](https://btengine.tradetron.tech/reports/tt-edge-weekly-put-ladder-6-5y-sample-48c129682bd7.html) | Returned `401 Authorization Required` in the review context. |
| Sweep report | [FastBT sweep report](https://btengine.tradetron.tech/reports/sweep-sweep-sample---nifty-intraday-short-straddle-bf90ba96c3a6.html) | Returned `401 Authorization Required` in the review context. |

The two user-supplied FastBT URLs `/fastbt` and `/fastbt/` were treated as one logical source because the no-slash URL resolved to the trailing-slash URL.

## FastBT: product definition

> FastBT is described as a simulation engine with one contract: predict what a live deployment actually does, quickly, across the markets and strategies that Tradetron’s Strategy Builder can express. [1]

Tradetron presents FastBT as a replacement for its previous backtest engine rather than as a minor patch. The page states that from **25 August 2026**, every Tradetron web and AI-chat backtest uses FastBT. It frames the engine around speed, market breadth, data integrity, live-fill comparison, walk-forward validation, Monte Carlo, and failure transparency. [1]

The headline claims shown on the page are summarized below. They are public vendor claims; they should not be treated as independently verified merely because the page labels them as measured or audited.

| Claim shown | Meaning in the page’s narrative |
|---|---|
| ₹20 flat per backtest | Same price for one day or full available history; walk-forward included. |
| Roughly 30 seconds | Claimed end-to-end time for a 4-year multi-leg positional backtest including its report. |
| Up to 486× faster | Maximum speed-up shown in paired old-engine/FastBT examples. |
| Six segments | NSE F&O, cash equity, BSE, MCX, crypto, and US markets. |
| 274.9 million bars | Option bars described as audited exchange-versus-store with zero OHLC violations. |
| 60+ metrics | Report breadth, including Monte Carlo and walk-forward. |
| 100% FastBT | Claim that all Tradetron backtests run on FastBT after the cutover date. |

## Why Tradetron says FastBT was built

The page openly describes prior complaints: queues lasting days, history beginning only in 2020, absent MCX and crypto coverage, and keywords that worked live but not in backtests. Tradetron says the new engine was instrumented so these complaints had measurable answers. It claims that 306 real user jobs were replayed before cutover, no outcomes were lost, approximately one in five previous-engine runs had returned no fills or report, and FastBT is fail-closed: it either returns a report or tells the user it cannot produce an honest result and refunds the credit. [1]

This is an important product-positioning choice. Instead of presenting only a faster number, the page makes **failure behavior** part of the backtest contract. The user should therefore ask not only “how fast is it?” but also “what does it refuse to simulate, what evidence supports the fill model, and when is a credit refunded?”

## Shipped capabilities listed by the page

The “shipped, not roadmapped” section lists native Custom Python, basket/list strategies that trade every member, removal of the five-year window cap, 86 additional cash symbols and ETFs, MCX copper/zinc/aluminium/silver, ₹0 brokerage default, rebuilt missing market days, one-day reports, native option Greeks, automatic refunds for refused runs, and AI-chat backtests on the same fleet. [1]

These are capabilities claimed as live on the page at the time of writing. A future AI should verify the current product state when executing a real backtest because the page itself says the tool set and coverage expand over time and may change.

## Speed evidence shown

The page reports paired runs with identical strategies, windows, and data under cold-cache, contended-box production conditions. Its table shows:

| Window | Previous engine | FastBT | Claimed speed-up |
|---|---:|---:|---:|
| 18 days, 1-minute | 35 minutes | 4.3 seconds | 486× |
| 6 months, 5-minute | 3 hours 21 minutes | 31 seconds | 393× |
| 2 months, 1-minute | 3 hours 35 minutes | 43 seconds | 299× |
| 3.7 years, hourly | 10 hours 48 minutes | 5 minutes 29 seconds | 118× |

The page separately claims that in a replay of 306 real user jobs, the median was 3.7× faster and the slowest tenth was 42× faster, with the same template, window, and fills. The distinction matters: the dramatic 118×–486× figures are selected paired examples, while the 3.7× median is positioned as a broader fleet result. [1]

## Market and strategy coverage

FastBT’s stated minute-level coverage includes NSE index options, BSE SENSEX/BANKEX, stock options and cash equity, MCX commodities, BTC/ETH crypto, US markets including SPX, and India VIX regime data. The strategy examples include short straddles, iron condors, re-entry straddles, weekly put ladders, Supertrend systems, EMA-band spreads, gamma-scalped straddles, covered calls, MCX crude condors, BTC strangles, SPX 0DTE strangles, cash-equity momentum baskets, VIX-gated strangles, and Custom Python. [1]

The claim is not that every instrument is always live-tradable for every user. Live tradability depends on the connected broker, venue, product, permissions, and applicable rules. The Universe page explicitly recommends checking a specific instrument with the assistant before building. [2]

## Data integrity and ground-truth story

FastBT describes an integrity layer with three pillars:

1. **Data audit.** It claims 274.9 million NIFTY and BANKNIFTY option bars for 2020–2025 were audited bar-by-bar; holes were repaired, ghost expiries deleted, per-date lot sizes taken from exchange circulars, and weekly sweeps used as guards. [1]
2. **Live-fill referee.** It claims 21,011 fills from live auto-trading deployments were replayed through the engine, including real slippage, and used to score the simulator. Reports are described as deterministic and explicit about what they cannot simulate. [1]
3. **Anti-overfit controls.** It includes walk-forward verdicts, parameter sweeps, Probabilistic Sharpe, and Monte-Carlo ranges. [1]

The correct interpretation is that FastBT is making a **validation architecture claim**: it says the simulator is checked against source data and actual execution outcomes. The page does not, by itself, provide an independently reproducible audit dataset or methodology sufficient for a third party to recalculate every result.

## Interactive report model

Every run is described as an interactive report rather than a single P&L number. The report is said to contain 60+ metrics across 20+ sections, including verdict and grade, equity and drawdown, Monte-Carlo ranges, VIX-regime splits, leg and exit attribution, trades drawn on the real chart, a live cost lab, and raw fills. Tooltips are intended to explain metrics in plain English. [1]

The page links to a 6.5-year sample report and a 12-variant sweep report. Both links returned **401 Authorization Required** during this review, so their internal sections and charts were not independently inspected. The report descriptions in this memory file therefore come from the public FastBT page, not from direct report inspection.

## Sweeps and walk-forward testing

A parameter sweep reruns the full backtest for each parameter combination. The page states that up to four parameters, up to ten values each, and up to sixteen combinations can be used in one run. Each cell is presented as a full backtest with charges, slippage, and the same refusal behavior—not an interpolated estimate. A cell can be opened into its own report. [1]

Walk-forward testing divides the historical window into an in-sample tuning period and an out-of-sample verification period. The page says the out-of-sample share can be as high as 90%, with 30% presented as a usual choice. Each variant receives a plain verdict: holds up, degrades, or fails out-of-sample. The preferred winner is the best in-sample variant that also holds up; if none does, the report should label the choice “least-bad, not deployable.” [1]

The supplied example is deliberately skeptical. In a 12-variant NIFTY intraday short-straddle sweep, all variants are profitable in-sample from +6.5% to +21.8%, but ten lose out-of-sample and the best in-sample result falls to −3.3%. The intended learning is that optimization without an out-of-sample test is a machine for finding luckiest historical parameters.

The page states that sweep pricing is per variant: a six-variant sweep costs ₹120, while walk-forward adds nothing to a single run or sweep. [1]

## Pricing and failure behavior

The page presents ₹20 per backtest as a flat price for any period, including full available history, with walk-forward included. It says there is no per-period multiplier, no execution-minute billing, no lock-in, and no demat account requirement merely to run a backtest. Failed or refused runs are said to refund automatically. It compares this with monthly plans and code-first platforms, but that competitor comparison is anonymized and should be treated as directional marketing. [1]

## Tradetron Universe: market map

> The Universe page positions Tradetron as one builder, backtester, and account spanning Indian index options, NSE F&O stocks, cash equity, MCX, crypto, and US markets. [2]

The page claims 8,500+ underlyings across 15+ exchanges and venues. Its six asset classes are:

| Asset class | Coverage described |
|---|---|
| Indian index options | NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, SENSEX, BANKEX; weekly/monthly expiries; ATM offset, premium, or delta selection. |
| Stock F&O | Every NSE F&O stock, with per-stock lot sizes and expiry rules. |
| Cash equity | 2,700+ NSE-listed stocks for CNC delivery and MIS intraday use. |
| MCX commodities | 60+ underlyings including gold, silver, crude oil, natural gas, and copper; futures and options. |
| Crypto | BTC, ETH, and more through connected venues such as Delta Exchange India, CoinDCX, ZebPay, CoinSwitch, and Bitbns; perpetuals/options where offered. |
| US markets | 3,500+ US stocks and ETFs plus SPX, NDX, XSP, SPY, and QQQ option markets, including 0DTE and weekly expiries where described. |

The Universe page says FastBT covers Indian index/stock options, MCX, BTC/ETH crypto, and US markets with 6.5 years of audited data at ₹20 per run. It repeats that actual live tradability depends on the connected broker or venue. [2]

## Scale and strategy composition

Tradetron describes lists and watchlists of up to 500 instruments per list, enabling a strategy to evaluate every member—for example, buying any stock in a momentum list that gaps up 2%. It also describes screener-driven selection, multi-leg/multi-set strategies, re-entries, and rollovers. [2]

The builder model is block-based: conditions, positions, and exits compose into options structures such as straddles, strangles, iron condors, butterflies, calendars, ratio spreads, and ladders. It also supports intraday and positional timing, RSI/moving averages/Supertrend/VWAP/range/breakout signals, TradingView alerts and webhooks, leg-level and strategy-level risk controls, and security-checked Custom Python. [2]

## Universe pricing and limitations

The Universe page shows plans starting at **₹300 per strategy per month**, **₹20 per backtest**, one free paper-trading deployment for life, and **0% profit share**. It warns that coverage reflects the catalog at the time of writing, expands over time, and is subject to broker/venue and regulatory constraints. Backtested results are hypothetical and not indicative of future results. [2]

## Claude case study: an example of research discipline

The linked case study follows a trader’s options idea across thirteen versions. Its narrative is not merely “AI generated a strategy”; it shows a loop of ambiguity checks, construction, backtesting, rejection, inversion, mirror testing, parameter variants, longer-history validation, and paper deployment. [3]

The first idea buys a monthly put around ₹50, takes partial profit at ₹100, and trails the rest. In the case study’s sample, 15 of 44 cycles doubled, but 29 decayed; the displayed net is negative. The analysis identifies payoff asymmetry: winners are capped while most premium-decay losers run toward near-zero.

The inverted ratio spread becomes marginally profitable, but the case study says the median cycle is tiny and the result depends on one good month. A mirror test runs the opposite structure and reports that 166 cycles sum to exactly zero against the mirror, with no deviation, as a harness sanity check. The case study then compares four management variants. Removing the stop increases drawdown severely; taking profit too early caps successful months; rolling to new strikes changes exposure; and adding a new spread every 500 points improves the displayed net in the example.

The longer 2020–2026 sample includes COVID and reduces the headline performance from the shorter sample. The case study presents this reduction as a reason to trust the longer-window figure more. It also mirrors the structure to calls and reports materially worse results, arguing that the strategy’s fit is regime-dependent rather than symmetric.

Ratio tests compare 1:1.5, 1:1.75, 1:2, and 1:3 structures, with 1:2 shown as the best return-to-drawdown point in that example. Strike-placement tests show ATM as the strongest setting. A VIX filter hypothesis is tested and rejected: high VIX is described as arriving with losses rather than reliably before them, so exiting on the VIX signal locks in losses and forfeits recovery.

The case study’s general lesson is methodological: use the AI to ask clarifying questions and iterate, but judge strategies through costs, drawdown, out-of-sample behavior, longer windows, mirror tests, and regime analysis. The figures are still vendor-provided case-study results and are not investment advice.

## AI-operational interpretation

FastBT and the Universe page together describe a **single-platform breadth-plus-verification proposition**: many markets and strategy types, one account, a common builder, a common backtest engine, paper trading, and MCP-driven conversational access. The differentiating message is not only “more markets”; it is that live logic, historical testing, risk controls, and AI-assisted construction are supposed to share the same strategy language.

A practical AI should therefore apply this sequence when using the product conceptually: verify that the instrument is resolvable and live-tradable through the user’s broker, clarify strategy semantics, backtest, run walk-forward or a sweep when parameters are uncertain, inspect drawdown and costs, paper-trade, and only then let the user decide about live deployment. No public page reviewed here authorizes an AI to make that final decision for the user.

## Safety and limitations

Tradetron’s own pages state that backtests are hypothetical, examples may be illustrative, coverage can change, live tradability depends on brokers/venues, and trading securities, derivatives, and crypto-assets carries substantial risk. FastBT’s public claims are not a substitute for inspecting the exact strategy, data window, charges, slippage, and report details for a user’s own case. [1] [2] [3]

## References

[1]: https://tradetron.tech/fastbt/ "Tradetron FastBT"
[2]: https://tradetron.tech/universe/ "Tradetron Universe"
[3]: https://tradetron.tech/build-with-claude/ "Tradetron case study: One idea, thirteen versions"
[4]: https://tradetron.tech/tt-assistant/ "Tradetron TT Assistant"
[5]: https://tradetron.tech/mcp-tools/ "Tradetron MCP tool reference"
