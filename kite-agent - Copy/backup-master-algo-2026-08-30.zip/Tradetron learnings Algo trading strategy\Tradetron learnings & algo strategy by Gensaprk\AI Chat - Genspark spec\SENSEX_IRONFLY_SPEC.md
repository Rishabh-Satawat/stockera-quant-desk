# SENSEX 0-DTE Iron Butterfly — Spec
Owner: Rishabh | Last updated: 26 Aug 2026
Status: PRE-BACKTEST. Never successfully backtested. Not live-eligible.

## Structure
Sell CE @ ATM SPOT('SENSEX','0')   | BFO | curr_weekexpiry | 1 lot
Sell PE @ ATM SPOT('SENSEX','0')   | BFO | curr_weekexpiry | 1 lot
Buy  CE @ ATM SPOT('SENSEX','3')   | BFO | curr_weekexpiry | 1 lot
Buy  PE @ ATM SPOT('SENSEX','-3')  | BFO | curr_weekexpiry | 1 lot
Wings ±300 pts. Lot size 20 (VERIFY).

## Governing arithmetic — check every number against these
max_loss   = (300 - credit) * lot
max_profit = credit * lot
Any threshold not derivable from these two lines is wrong.

## Parameters (v1, untested)
premium_floor   170   -> ML 2600 / MP 3400   [PRIMARY SWEEP AXIS]
stop_loss      -1700   (65% of ML)
hard_target     2000   (was 3200 — unreachable, corrected 26 Aug)
trail_trigger   1400   (was 2600 — corrected 26 Aug)
trail_giveback   400
breach_exit      250 pts  (primary intraday risk control)
entry_window    0945-1000
time_exit       1445   (clears CAS 3:15 index staleness — do not move later)
gap_filter      |Change%| <= 1
capital        125000

## Exchange rules
Index spot (gap filter, breach exit) -> BSE_IDX
Options (premium floor, all 4 legs)  -> BFO
Rendered string for index rows: PENDING VERIFICATION

## Open questions
1. Does BSE_IDX render as 'BSE_IDX,SENSEX,,,,'?      UNRESOLVED
2. Does EntryUnderlyingPrice fire in FastBT?          UNRESOLVED - read exit attribution
3. SENSEX lot size, current and historical            UNRESOLVED - affects all ₹ figures
4. Lot-size regime changes inside backtest window     UNRESOLVED - ₹ stops = different
                                                       point-moves across eras

## Environment (26 Aug 2026)
INDIA VIX 10.6, IVP 10-15. Bottom-decile IV = worst regime for short premium.
Est. ATM straddle at 0945 expiry morning: 150-180 pts. Floor of 170 is marginal.
Strategy may correctly refuse to trade. Let it.

## Decisions log
26 Aug - Keep EntryUnderlyingPrice; reject Traded Instrument proxy (8 positional
         args = argument-shift risk; Tradetron's own case study documents this bug).
26 Aug - Skip VIX filters. Tradetron case study: 14 configs, entry+exit gates,
         thresholds 16-40, ZERO reduced drawdown. High VIX arrives with the loss.
26 Aug - Strategy-level TSL stays 0/0/0. Trailing lives in Universal Exit via
         Max Profit keyword. Running both = two mechanisms fighting.
26 Aug - Backtest engine is FastBT since 25 Aug 2026. ₹20 flat, full history,
         walk-forward free. Brokerage defaults to ZERO — set it manually.
         Stops still fill on close, not bar high/low. Backtest will flatter the stop.
26 Aug - Multiplier does NOT scale PNL thresholds. If deploying >1x, wrap every
         rupee figure as Number × Multiplier.

## Backlog (post-validation only)
- Convert breach exit from EXIT to re-centring adjustment (Repair Once).
  Tradetron's own case study: best improvement was structural, not filter-based.
- Per-leg stops with move-to-cost on the surviving short.
- Delta-based wing selection (Find Strike has SENSEX restrictions — verify).
